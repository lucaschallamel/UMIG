package umig.repository

import umig.utils.DatabaseUtil
import umig.utils.EnhancedEmailService
import umig.utils.AuthenticationService
import umig.service.StepDataTransformationService
import umig.service.StatusService
import umig.dto.StepInstanceDTO
import umig.dto.StepMasterDTO
// Note: Audit logging is now enabled for step status changes
// import umig.repository.InstructionRepository  // Not used
import umig.repository.AuditLogRepository      // Re-enabled for step status notifications
import java.util.UUID
import java.sql.SQLException
import java.sql.Timestamp
import groovy.sql.Sql
import groovy.util.logging.Slf4j

// TD-003 Phase 2G: Integrated StatusService for centralized status management
// Updated: 2025-09-20 14:30 - Labels integration with frontend field mapping
/**
 * Repository for STEP master and instance data, including impacted teams and iteration scopes.
 */
@Slf4j
class StepRepository {

    /**
     * StatusService instance for centralized status management (TD-003 Phase 2G)
     * Uses lazy loading pattern to prevent class loading issues
     */
    private static StatusService statusService

    /**
     * Get StatusService instance using lazy loading pattern (TD-003 Phase 2G)
     * @return StatusService instance for centralized status management
     */
    private static StatusService getStatusService() {
        if (!statusService) {
            statusService = new StatusService()
            log.debug("StepRepository: StatusService lazy loaded for centralized status management")
        }
        return statusService
    }

    /**
     * Get COMPLETED status name for Step entities using StatusService
     * @return String status name for COMPLETED step status
     */
    private static String getCompletedStepStatus() {
        try {
            List<String> validStatuses = getStatusService().getValidStatusNames('Step')
            return validStatuses.find { it.equalsIgnoreCase('COMPLETED') } ?: 'COMPLETED'
        } catch (Exception e) {
            log.warn("StepRepository: Failed to get COMPLETED status via StatusService, using fallback", e)
            return 'COMPLETED'
        }
    }

    /**
     * Get IN_PROGRESS status name for Step entities using StatusService
     * @return String status name for IN_PROGRESS step status
     */
    private static String getInProgressStepStatus() {
        try {
            List<String> validStatuses = getStatusService().getValidStatusNames('Step')
            return validStatuses.find { it.equalsIgnoreCase('IN_PROGRESS') } ?: 'IN_PROGRESS'
        } catch (Exception e) {
            log.warn("StepRepository: Failed to get IN_PROGRESS status via StatusService, using fallback", e)
            return 'IN_PROGRESS'
        }
    }

    /**
     * Get OPEN status name for Step entities using StatusService
     * @return String status name for OPEN step status
     */
    private static String getOpenStepStatus() {
        try {
            List<String> validStatuses = getStatusService().getValidStatusNames('Step')
            return validStatuses.find { it.equalsIgnoreCase('OPEN') } ?: 'OPEN'
        } catch (Exception e) {
            log.warn("StepRepository: Failed to get OPEN status via StatusService, using fallback", e)
            return 'OPEN'
        }
    }

    /**
     * Service for transforming database rows to StepInstanceDTO and StepMasterDTO
     * Following US-056F Dual DTO Architecture pattern
     */
    private final StepDataTransformationService transformationService = new StepDataTransformationService()
    /**
     * Fetches master STEP data by code and number.
     */
    def findStepMaster(String sttCode, Integer stmNumber) {
        DatabaseUtil.withSql { sql ->
            return sql.firstRow('''
                SELECT stm.stm_id, stm.stt_code, stm.stm_number, stm.stm_name, stm.stm_description
                FROM steps_master_stm stm
                WHERE stm.stt_code = :sttCode AND stm.stm_number = :stmNumber
            ''', [sttCode: sttCode, stmNumber: stmNumber])
        }
    }

    /**
     * Fetches all impacted team IDs for a STEP (from join table).
     */
    def findImpactedTeamIds(UUID stmId) {
        DatabaseUtil.withSql { sql ->
            return sql.rows('''
                SELECT tms_id
                FROM steps_master_stm_x_teams_tms_impacted
                WHERE stm_id = :stmId
            ''', [stmId: stmId])*.tms_id
        }
    }

    /**
     * Fetches all iteration types for a STEP (from join table).
     */
    def findIterationScopes(String sttCode, Integer stmNumber) {
        DatabaseUtil.withSql { sql ->
            return sql.rows('''
                SELECT itt_id
                FROM steps_master_stm_x_iteration_types_itt
                WHERE stt_code = :sttCode AND stm_number = :stmNumber
            ''', [sttCode: sttCode, stmNumber: stmNumber])*.itt_id
        }
    }

    /**
     * Fetches all master steps with basic information for dropdowns
     * @return List of master steps with id, code, number, name, and type
     */
    def findAllMasterSteps() {
        DatabaseUtil.withSql { sql ->
            return sql.rows('''
                SELECT 
                    stm.stm_id,
                    stm.stt_code,
                    stm.stm_number,
                    stm.stm_name,
                    stm.stm_description,
                    stt.stt_name
                FROM steps_master_stm stm
                JOIN step_types_stt stt ON stm.stt_code = stt.stt_code
                ORDER BY stm.stt_code, stm.stm_number
            ''')        }
    }

    /**
     * Finds master steps with pagination, sorting, and filtering for Admin GUI
     * @param filters Map of filter parameters
     * @param pageNumber Page number (1-based)
     * @param pageSize Number of items per page
     * @param sortField Field to sort by
     * @param sortDirection Sort direction (asc/desc)
     * @return Map with data, pagination info, and filters
     */
    def findMasterStepsWithFilters(Map filters, int pageNumber = 1, int pageSize = 50, String sortField = null, String sortDirection = 'asc') {
        DatabaseUtil.withSql { sql ->
            pageNumber = Math.max(1, pageNumber)
            pageSize = Math.min(100, Math.max(1, pageSize))
            
            def whereConditions = []
            def params = []
            
            // Build dynamic WHERE clause
            // Note: Status filtering removed for master steps as they don't have status
            // Status is only available for step instances (steps_instance_sti)
            
            // Owner ID filtering (phases own steps via phm_id)
            if (filters.ownerId) {
                whereConditions << "stm.phm_id = ?"
                params << UUID.fromString(filters.ownerId as String)
            }
            
            // Search functionality
            if (filters.search) {
                whereConditions << "(stm.stm_name ILIKE ? OR stm.stm_description ILIKE ?)"
                params << "%${filters.search}%".toString()
                params << "%${filters.search}%".toString()
            }
            
            def whereClause = whereConditions ? "WHERE " + whereConditions.join(" AND ") : ""
            
            // Count query with JOINs for hierarchy information
            def countQuery = """
                SELECT COUNT(DISTINCT stm.stm_id) as total
                FROM steps_master_stm stm
                JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
                JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id
                JOIN plans_master_plm plm ON sqm.plm_id = plm.plm_id
                ${whereClause}
            """
            def totalCount = sql.firstRow(countQuery, params)?.total ?: 0
            
            // Validate sort field (removed stm_status as master steps don't have status)
            def allowedSortFields = ['stm_id', 'stm_name', 'stm_number', 'stm_description', 'instruction_count', 'instance_count', 'plm_name', 'sqm_name', 'phm_name', 'team_name', 'step_code', 'environment_role_name', 'predecessor_name']
            if (!sortField || !allowedSortFields.contains(sortField)) {
                sortField = 'stm_name'
            }
            sortDirection = (sortDirection?.toLowerCase() == 'desc') ? 'DESC' : 'ASC'
            
            // Data query with computed fields and hierarchy information
            def offset = (pageNumber - 1) * pageSize
            def dataQuery = """
                SELECT DISTINCT stm.*,
                       phm.phm_name,
                       sqm.sqm_name,
                       plm.plm_name,
                       tms.tms_name as team_name,
                       CONCAT(stm.stt_code, '-', LPAD(stm.stm_number::text, 4, '0')) as step_code,
                       enr.enr_name as environment_role_name,
                       pred.stm_name as predecessor_name,
                       CONCAT(pred.stt_code, '-', LPAD(pred.stm_number::text, 4, '0')) as predecessor_code,
                       COALESCE(instruction_counts.instruction_count, 0) as instruction_count,
                       COALESCE(instance_counts.instance_count, 0) as instance_count
                FROM steps_master_stm stm
                JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
                JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id
                JOIN plans_master_plm plm ON sqm.plm_id = plm.plm_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                LEFT JOIN environment_roles_enr enr ON stm.enr_id_target = enr.enr_id
                LEFT JOIN steps_master_stm pred ON stm.stm_id_predecessor = pred.stm_id
                LEFT JOIN (
                    SELECT stm_id, COUNT(*) as instruction_count
                    FROM instructions_master_inm
                    GROUP BY stm_id
                ) instruction_counts ON stm.stm_id = instruction_counts.stm_id
                LEFT JOIN (
                    SELECT stm_id, COUNT(*) as instance_count
                    FROM steps_instance_sti
                    GROUP BY stm_id
                ) instance_counts ON stm.stm_id = instance_counts.stm_id
                ${whereClause}
                ORDER BY ${['instruction_count', 'instance_count', 'team_name', 'step_code', 'environment_role_name', 'predecessor_name'].contains(sortField) ? sortField : (['plm_name', 'sqm_name', 'phm_name'].contains(sortField) ? sortField : 'stm.' + sortField)} ${sortDirection}
                LIMIT ${pageSize} OFFSET ${offset}
            """
            
            def steps = sql.rows(dataQuery, params)
            def enrichedSteps = steps.collect { enrichMasterStepWithStatusMetadata(it) }
            
            return [
                data: enrichedSteps,
                pagination: [
                    page: pageNumber,
                    size: pageSize,
                    total: totalCount,
                    totalPages: (int) Math.ceil((double) totalCount / (double) pageSize)
                ],
                filters: filters
            ]
        }
    }

    /**
     * Enriches master step data without status information (master steps don't have status).
     * @param row Database row containing master step data
     * @return Enhanced step map suitable for Admin GUI
     */
    private Map enrichMasterStepWithStatusMetadata(Map row) {
        return [
            stm_id: row.stm_id,
            // Core step fields
            stm_name: row.stm_name,
            stm_description: row.stm_description,
            stm_number: row.stm_number,
            stm_order: row.stm_number, // Frontend expects stm_order, which corresponds to stm_number in database
            stm_duration_minutes: row.stm_duration_minutes,
            phm_id: row.phm_id,
            tms_id_owner: row.tms_id_owner,
            stt_code: row.stt_code,
            enr_id_target: row.enr_id_target,
            stm_id_predecessor: row.stm_id_predecessor,
            // NEW FIELDS - Additional attributes for VIEW modal display
            team_name: row.team_name,
            step_code: row.step_code,
            environment_role_name: row.environment_role_name,
            predecessor_name: row.predecessor_name,
            predecessor_code: row.predecessor_code,
            // Audit fields - added for VIEW modal display
            created_by: row.created_by,
            created_at: row.created_at,
            updated_by: row.updated_by,
            updated_at: row.updated_at,
            // Hierarchy fields from JOINs
            plm_name: row.plm_name,
            sqm_name: row.sqm_name,
            phm_name: row.phm_name,
            // Computed fields from joins
            instruction_count: row.instruction_count ?: 0,
            instance_count: row.instance_count ?: 0
            // Note: Master steps don't have status - status exists only on step instances
        ]
    }

    /**
     * Finds a single master step by ID with hierarchy data and computed fields
     * @param stepId The UUID of the master step
     * @return Map containing master step data or null if not found
     */
    def findMasterStepById(UUID stepId) {
        DatabaseUtil.withSql { sql ->
            def result = sql.firstRow("""
                SELECT DISTINCT stm.*,
                       phm.phm_name,
                       sqm.sqm_name,
                       plm.plm_name,
                       tms.tms_name as team_name,
                       CONCAT(stm.stt_code, '-', LPAD(stm.stm_number::text, 4, '0')) as step_code,
                       enr.enr_name as environment_role_name,
                       pred.stm_name as predecessor_name,
                       CONCAT(pred.stt_code, '-', LPAD(pred.stm_number::text, 4, '0')) as predecessor_code,
                       COALESCE(instruction_counts.instruction_count, 0) as instruction_count,
                       COALESCE(instance_counts.instance_count, 0) as instance_count
                FROM steps_master_stm stm
                JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
                JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id
                JOIN plans_master_plm plm ON sqm.plm_id = plm.plm_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                LEFT JOIN environment_roles_enr enr ON stm.enr_id_target = enr.enr_id
                LEFT JOIN steps_master_stm pred ON stm.stm_id_predecessor = pred.stm_id
                LEFT JOIN (
                    SELECT stm_id, COUNT(*) as instruction_count
                    FROM instructions_master_inm
                    GROUP BY stm_id
                ) instruction_counts ON stm.stm_id = instruction_counts.stm_id
                LEFT JOIN (
                    SELECT stm_id, COUNT(*) as instance_count
                    FROM steps_instance_sti
                    GROUP BY stm_id
                ) instance_counts ON stm.stm_id = instance_counts.stm_id
                WHERE stm.stm_id = :stepId
            """, [stepId: stepId])
            
            return result ? enrichMasterStepWithStatusMetadata(result) : null
        }
    }

    /**
     * Fetches master steps filtered by migration ID
     * @param migrationId The UUID of the migration to filter by
     * @return List of master steps that belong to the specified migration
     */
    def findMasterStepsByMigrationId(UUID migrationId) {
        DatabaseUtil.withSql { sql ->
            return sql.rows('''
                SELECT DISTINCT
                    stm.stm_id,
                    stm.stt_code,
                    stm.stm_number,
                    stm.stm_name,
                    stm.stm_description,
                    stt.stt_name
                FROM steps_master_stm stm
                JOIN step_types_stt stt ON stm.stt_code = stt.stt_code
                JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
                JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id
                JOIN plans_master_plm plm ON sqm.plm_id = plm.plm_id
                JOIN iterations_ite ite ON plm.plm_id = ite.plm_id
                WHERE ite.mig_id = :migrationId
                ORDER BY stm.stt_code, stm.stm_number
            ''', [migrationId: migrationId])
        }
    }

    /**
     * Fetches the first step instance for a given master step, for the first plan instance of the first iteration/migration (per current MVP logic).
     */
    def findFirstStepInstance(String sttCode, Integer stmNumber) {
        DatabaseUtil.withSql { sql ->
            return sql.firstRow('''
                SELECT sti.*
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                JOIN plans_instance_pli pli ON sti.phi_id = pli.pli_id
                JOIN plans_plm plm ON pli.plm_id = plm.plm_id
                JOIN iterations_ite ite ON plm.ite_id = ite.ite_id
                JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                WHERE stm.stt_code = :sttCode AND stm.stm_number = :stmNumber
                ORDER BY mig.mig_id, ite.ite_id, plm.plm_id, pli.pli_id, sti.sti_id
                LIMIT 1
            ''', [sttCode: sttCode, stmNumber: stmNumber])
        }
    }

    /**
     * Fetches filtered step instances for the runsheet with hierarchical filtering.
     * Returns steps grouped by sequence and phase with all required attributes.
     */
    List<Map> findFilteredStepInstances(Map filters) {
        DatabaseUtil.withSql { sql ->
            def query = '''
                SELECT
                    -- Step instance data
                    sti.sti_id, stm.stt_code, stm.stm_number, sti.sti_name, sti.sti_status,
                    sti.sti_duration_minutes, stm.tms_id_owner,
                    -- Master step data
                    stm.stm_id, stm.stm_name,
                    -- Sequence and phase hierarchy
                    sqm.sqm_id, sqm.sqm_name, sqm.sqm_order,
                    phm.phm_id, phm.phm_name, phm.phm_order,
                    -- Plan hierarchy
                    plm.plm_id, plm.plm_name,
                    -- Instance hierarchy with order fields
                    pli.pli_id, sqi.sqi_id, sqi.sqi_order, phi.phi_id, phi.phi_order,
                    -- Team owner information
                    tms.tms_name as owner_team_name,
                    -- Iteration and migration context
                    ite.ite_id, ite.ite_name,
                    mig.mig_id, mig.mig_name
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN phases_master_phm phm ON phi.phm_id = phm.phm_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN sequences_master_sqm sqm ON sqi.sqm_id = sqm.sqm_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                WHERE 1=1
            '''
            
            def params = [:]
            
            // Add hierarchical filters
            if (filters.migrationId) {
                query += ' AND mig.mig_id = :migrationId'
                params.migrationId = UUID.fromString(filters.migrationId as String)
            }
            
            if (filters.iterationId) {
                query += ' AND ite.ite_id = :iterationId'
                params.iterationId = UUID.fromString(filters.iterationId as String)
            }
            
            if (filters.planId) {
                query += ' AND pli.pli_id = :planId'
                params.planId = UUID.fromString(filters.planId as String)
            }
            
            if (filters.sequenceId) {
                query += ' AND sqi.sqi_id = :sequenceId'
                params.sequenceId = UUID.fromString(filters.sequenceId as String)
            }
            
            if (filters.phaseId) {
                query += ' AND phi.phi_id = :phaseId'
                params.phaseId = UUID.fromString(filters.phaseId as String)
            }
            
            // Add team filter
            if (filters.teamId) {
                query += ' AND stm.tms_id_owner = :teamId'
                params.teamId = Integer.parseInt(filters.teamId as String)
            }
            
            // Add label filter (through step-label join table)
            if (filters.labelId) {
                query += '''
                    AND EXISTS (
                        SELECT 1 FROM labels_lbl_x_steps_master_stm lxs 
                        WHERE lxs.stm_id = stm.stm_id AND lxs.lbl_id = :labelId
                    )
                '''
                params.labelId = Integer.parseInt(filters.labelId as String)
            }
            
            // Order by sequence, phase, and step number
            query += '''
                ORDER BY sqm.sqm_order, phm.phm_order, stm.stm_number
            '''
            
            def results = sql.rows(query, params)
            
            // Transform results to frontend-compatible format
            return results.collect { row ->
                enrichStepInstanceWithStatusMetadata(row)
            } as List<Map>
        }
    }

    /**
     * Fetches all labels associated with a step master.
     * @param stmId The UUID of the step master
     * @return A list of labels with id, name, description, and color
     */
    def findLabelsByStepId(UUID stmId) {
        DatabaseUtil.withSql { sql ->
            def results = sql.rows('''
                SELECT l.lbl_id, l.lbl_name, l.lbl_description, l.lbl_color
                FROM labels_lbl l
                JOIN labels_lbl_x_steps_master_stm lxs ON l.lbl_id = lxs.lbl_id
                WHERE lxs.stm_id = :stmId
                ORDER BY l.lbl_name
            ''', [stmId: stmId])
            
            return results.collect { row ->
                [
                    id: row.lbl_id,
                    name: row.lbl_name,
                    description: row.lbl_description,
                    color: row.lbl_color
                ]
            }
        }
    }

    /**
     * Updates step instance status and sends notification emails.
     * @param stepInstanceId The UUID of the step instance
     * @param statusId The new status ID (Integer)
     * @param userId Optional user ID for audit logging
     * @return Map with success status and email send results
     */
    Map updateStepInstanceStatusWithNotification(UUID stepInstanceId, Integer statusId, Integer userId = null) {
        DatabaseUtil.withSql { sql ->
            try {
                println "StepRepository.updateStepInstanceStatusWithNotification called:"
                println "  - stepInstanceId: ${stepInstanceId}"
                println "  - statusId: ${statusId}"
                println "  - userId: ${userId}"
                
                // Validate status exists and get status name
                def status = sql.firstRow("SELECT sts_id, sts_name FROM status_sts WHERE sts_id = :statusId AND sts_type = 'Step'",
                    [statusId: statusId])
                
                if (!status) {
                    return [success: false, error: "Invalid status ID: ${statusId}"]
                }
                
                println "  - Status name: ${status.sts_name}"
                
                def statusName = status.sts_name
                
                // Get current step instance data with all fields needed for email templates
                def stepInstance = sql.firstRow('''
                    SELECT 
                        sti.sti_id, sti.sti_name, sti.sti_status, sti.stm_id, sti.sti_duration_minutes,
                        stm.stt_code as sti_code, stm.stm_number, stm.tms_id_owner, stm.stm_description as sti_description,
                        mig.mig_name as migration_name,
                        ite.ite_name as iteration_name,
                        plm.plm_name as plan_name,
                        owner_team.tms_name as team_name,
                        -- Environment information
                        enr.enr_name as environment_role_name,
                        env.env_name as environment_name,
                        -- Impacted teams (comma-separated list)
                        COALESCE(
                            STRING_AGG(impacted_team.tms_name, ', ' ORDER BY impacted_team.tms_name), 
                            ''
                        ) as impacted_teams,
                        -- Recent comments (for email template) - simple empty list for compatibility
                        '' as recentComments
                    FROM steps_instance_sti sti
                    JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                    LEFT JOIN teams_tms owner_team ON stm.tms_id_owner = owner_team.tms_id
                    LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id
                    JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                    JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                    JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                    JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                    JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                    JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                    -- Join to get actual environment name for this iteration and role
                    LEFT JOIN environments_env_x_iterations_ite eei ON eei.ite_id = ite.ite_id AND eei.enr_id = sti.enr_id
                    LEFT JOIN environments_env env ON eei.env_id = env.env_id
                    -- Join to get impacted teams  
                    LEFT JOIN steps_master_stm_x_teams_tms_impacted impacted_rel ON stm.stm_id = impacted_rel.stm_id
                    LEFT JOIN teams_tms impacted_team ON impacted_rel.tms_id = impacted_team.tms_id
                    WHERE sti.sti_id = :stepInstanceId
                    GROUP BY sti.sti_id, sti.sti_name, sti.sti_status, sti.stm_id, sti.sti_duration_minutes,
                             stm.stt_code, stm.stm_number, stm.tms_id_owner, stm.stm_description,
                             mig.mig_name, ite.ite_name, plm.plm_name, owner_team.tms_name,
                             enr.enr_name, env.env_name
                ''', [stepInstanceId: stepInstanceId])
                
                if (!stepInstance) {
                    return [success: false, error: "Step instance not found"]
                }
                
                // Debug: Log all fields available in stepInstance
                println "  - Repository stepInstance fields: ${stepInstance.keySet()}"
                println "  - Repository stepInstance.recentComments: ${stepInstance.recentComments}"
                println "  - Repository stepInstance.impacted_teams: ${stepInstance.impacted_teams}"
                
                def oldStatusId = stepInstance.sti_status
                
                // Get old status name for notification
                def oldStatus = sql.firstRow("SELECT sts_name FROM status_sts WHERE sts_id = :oldStatusId", [oldStatusId: oldStatusId])?.sts_name
                
                // Calculate end time in Groovy instead of SQL to avoid PostgreSQL parameter type issues
                def completedStatusName = getCompletedStepStatus()
                def shouldSetEndTime = (statusName == completedStatusName)
                def endTime = shouldSetEndTime ? new java.sql.Timestamp(System.currentTimeMillis()) : null

                // Calculate updated_by in Groovy to avoid PostgreSQL parameter type issues
                def updatedBy = userId ? userId.toString() : 'confluence_user'

                // Update the status with audit fields - PostgreSQL parameter type fix
                def updateCount = sql.executeUpdate('''
                    UPDATE steps_instance_sti
                    SET sti_status = :statusId,
                        sti_end_time = COALESCE(:endTime, sti_end_time),
                        updated_by = :updatedBy,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE sti_id = :stepInstanceId
                ''', [
                    statusId: statusId,
                    endTime: endTime,
                    updatedBy: updatedBy,
                    stepInstanceId: stepInstanceId
                ])
                
                if (updateCount != 1) {
                    return [success: false, error: "Failed to update step status"]
                }
                
                // Get teams for notification (owner team + impacted teams)
                def teams = getTeamsForNotification(sql, stepInstance.stm_id as UUID, stepInstance.tms_id_owner as Integer)

                // Get IT cutover team - find team with 'IT Cutover' or 'Cutover' in name
                // This is a simple approach for now - can be enhanced later with role-based lookup
                def cutoverTeam = sql.firstRow('''
                    SELECT tms_id, tms_name, tms_email
                    FROM teams_tms
                    WHERE LOWER(tms_name) LIKE '%cutover%'
                    OR LOWER(tms_name) LIKE '%it cutover%'
                    LIMIT 1
                ''')

                // NOTE: Email notifications are handled by StepNotificationIntegration.groovy
                // This eliminates duplicate email calls that were causing conflicts
                // StepNotificationIntegration calls EnhancedEmailService with proper data enrichment
                def emailsSent = 0
                println "[NOTIFICATION] Email notifications handled by StepNotificationIntegration.groovy"

                // REMOVED: Duplicate email notification code to fix dual system conflicts
                // The email sending is now centralized in StepNotificationIntegration.groovy
                // which already calls EnhancedEmailService.sendStepStatusChangedNotificationWithUrl()

                try {
                    // Placeholder for any future non-email notification logic
                    emailsSent = 1  // Assume email was sent by StepNotificationIntegration
                } catch (Exception emailError) {
                    // Log but don't fail the status update
                    emailsSent = 0  // No emails sent due to error
                    println "[NOTIFICATION] ⚠️ WARNING: Email notification failed but status was updated successfully"
                    println "  - Error: ${emailError.message}"
                    emailError.printStackTrace()

                    // Log the email failure as an audit event
                    try {
                        // Calculate recipient list for audit (explicit type per ADR-031/ADR-043)
                        List<String> recipientEmails = []
                        teams.each { team ->
                            if (team.tms_email) {
                                recipientEmails.add(team.tms_email as String)
                            }
                        }
                        if (cutoverTeam?.tms_email) {
                            recipientEmails.add(cutoverTeam.tms_email as String)
                        }

                        AuditLogRepository.logEmailFailed(
                            sql,
                            userId,
                            stepInstanceId,
                            recipientEmails,
                            "[UMIG] Step Status Changed: ${stepInstance.sti_name}" as String,
                            emailError.message as String,
                            'STEP_INSTANCE'  // Entity type for step status changes
                        )
                        println "[AUDIT] ✅ Email failure logged to audit trail"
                    } catch (Exception auditLogError) {
                        println "[AUDIT] ⚠️ Failed to log email failure to audit: ${auditLogError.message}"
                    }
                }

                // Add audit log entry (within the same transaction)
                try {
                    println "[AUDIT] Creating audit log entry for status change..."
                    println "  - User ID: ${userId ?: 'System'}"
                    println "  - Step ID: ${stepInstanceId}"
                    println "  - Status change: ${oldStatus} -> ${statusName}"

                    AuditLogRepository.logStepStatusChange(
                        sql,
                        userId,
                        stepInstanceId,
                        oldStatus as String,
                        statusName as String
                    )
                    println "[AUDIT] ✅ Audit log entry created successfully"
                } catch (Exception auditError) {
                    // Log but don't fail the status update
                    println "[AUDIT] ⚠️ WARNING: Audit logging failed but status was updated successfully"
                    println "  - Error: ${auditError.message}"
                    auditError.printStackTrace()
                }

                return [success: true, statusChanged: true, oldStatus: oldStatus, newStatus: statusName, emailsSent: emailsSent]
                
            } catch (Exception e) {
                return [success: false, error: e.message]
            }
        }
    }

    /**
     * Marks a step instance as opened by a PILOT and sends notifications.
     * @param stepInstanceId The UUID of the step instance
     * @param userId Optional user ID for audit logging
     * @return Map with success status and email send results
     */
    Map openStepInstanceWithNotification(UUID stepInstanceId, Integer userId = null) {
        DatabaseUtil.withSql { sql ->
            try {
                // Get step instance data with all fields needed for email templates
                def stepInstance = sql.firstRow('''
                    SELECT 
                        sti.sti_id, sti.sti_name, sti.stm_id, sti.sti_status, sti.sti_duration_minutes,
                        stm.stt_code as sti_code, stm.stm_number, stm.tms_id_owner, stm.stm_description as sti_description,
                        mig.mig_name as migration_name,
                        ite.ite_name as iteration_name,
                        plm.plm_name as plan_name,
                        owner_team.tms_name as team_name,
                        -- Environment information
                        enr.enr_name as environment_role_name,
                        env.env_name as environment_name,
                        -- Impacted teams (comma-separated list)
                        COALESCE(
                            STRING_AGG(impacted_team.tms_name, ', ' ORDER BY impacted_team.tms_name), 
                            ''
                        ) as impacted_teams,
                        -- Recent comments (for email template) - simple empty list for compatibility
                        '' as recentComments
                    FROM steps_instance_sti sti
                    JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                    LEFT JOIN teams_tms owner_team ON stm.tms_id_owner = owner_team.tms_id
                    LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id
                    JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                    JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                    JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                    JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                    JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                    JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                    -- Join to get actual environment name for this iteration and role
                    LEFT JOIN environments_env_x_iterations_ite eei ON eei.ite_id = ite.ite_id AND eei.enr_id = sti.enr_id
                    LEFT JOIN environments_env env ON eei.env_id = env.env_id
                    -- Join to get impacted teams  
                    LEFT JOIN steps_master_stm_x_teams_tms_impacted impacted_rel ON stm.stm_id = impacted_rel.stm_id
                    LEFT JOIN teams_tms impacted_team ON impacted_rel.tms_id = impacted_team.tms_id
                    WHERE sti.sti_id = :stepInstanceId
                    GROUP BY sti.sti_id, sti.sti_name, sti.sti_status, sti.stm_id, sti.sti_duration_minutes,
                             stm.stt_code, stm.stm_number, stm.tms_id_owner, stm.stm_description,
                             mig.mig_name, ite.ite_name, plm.plm_name, owner_team.tms_name,
                             enr.enr_name, env.env_name
                ''', [stepInstanceId: stepInstanceId])
                
                if (!stepInstance) {
                    return [success: false, error: "Step instance not found"]
                }
                
                // Check if already opened
                // Convert status ID to name for backward compatibility check
                def statusName = sql.firstRow("SELECT sts_name FROM status_sts WHERE sts_id = :statusId", [statusId: stepInstance.sti_status])?.sts_name
                if (statusName in ["${getOpenStepStatus()}", "${getInProgressStepStatus()}", "${getCompletedStepStatus()}"]) {
                    return [success: false, error: "Step has already been opened (status: ${stepInstance.sti_status})"]
                }
                
                // Mark as opened by updating status to OPEN
                def updateCount = sql.executeUpdate('''
                    UPDATE steps_instance_sti 
                    SET sti_status = (SELECT sts_id FROM status_sts WHERE sts_name = '${getOpenStepStatus()}' AND sts_type = 'Step'),
                        sti_start_time = CURRENT_TIMESTAMP,
                        usr_id_owner = :userId
                    WHERE sti_id = :stepInstanceId
                ''', [userId: userId, stepInstanceId: stepInstanceId])
                
                if (updateCount != 1) {
                    return [success: false, error: "Failed to open step"]
                }
                
                // Get teams for notification
                def teams = getTeamsForNotification(sql, stepInstance.stm_id as UUID, stepInstance.tms_id_owner as Integer)

                // TODO: Implement EnhancedEmailService for notifications
                // EnhancedEmailService.sendStepOpenedNotificationWithUrl(
                //     stepInstance as Map,
                //     teams,
                //     userId
                // )
                println "TODO: Send step opened notification email to ${teams.size()} teams"
                println "Step opened: ${stepInstance.sti_name}"

                return [success: true, stepOpened: true]
                
            } catch (Exception e) {
                return [success: false, error: e.message]
            }
        }
    }

    /**
     * Marks an instruction as completed and sends notifications.
     * @param instructionId The UUID of the instruction instance
     * @param stepInstanceId The UUID of the step instance
     * @param userId Optional user ID for audit logging
     * @return Map with success status and email send results
     */
    Map completeInstructionWithNotification(UUID instructionId, UUID stepInstanceId, Integer userId = null) {
        DatabaseUtil.withSql { sql ->
            try {
                // Get instruction data
                def instruction = sql.firstRow('''
                    SELECT 
                        ini.ini_id, ini.ini_is_completed,
                        inm.inm_order, inm.inm_body as ini_name,
                        inm.tms_id as instruction_team_id
                    FROM instructions_instance_ini ini
                    JOIN instructions_master_inm inm ON ini.inm_id = inm.inm_id
                    WHERE ini.ini_id = :instructionId
                ''', [instructionId: instructionId])
                
                if (!instruction) {
                    return [success: false, error: "Instruction not found"]
                }
                
                // Check if already completed
                if (instruction.ini_is_completed) {
                    return [success: false, error: "Instruction already completed"]
                }
                
                // Get step instance data with all fields needed for email templates
                def stepInstance = sql.firstRow('''
                    SELECT 
                        sti.sti_id, sti.sti_name, sti.stm_id, sti.sti_duration_minutes,
                        stm.stt_code as sti_code, stm.stm_number, stm.tms_id_owner, stm.stm_description as sti_description,
                        mig.mig_name as migration_name,
                        ite.ite_name as iteration_name,
                        plm.plm_name as plan_name,
                        owner_team.tms_name as team_name,
                        -- Environment information
                        enr.enr_name as environment_role_name,
                        env.env_name as environment_name,
                        -- Impacted teams (comma-separated list)
                        COALESCE(
                            STRING_AGG(impacted_team.tms_name, ', ' ORDER BY impacted_team.tms_name), 
                            ''
                        ) as impacted_teams,
                        -- Recent comments (for email template) - simple empty list for compatibility
                        '' as recentComments
                    FROM steps_instance_sti sti
                    JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                    LEFT JOIN teams_tms owner_team ON stm.tms_id_owner = owner_team.tms_id
                    LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id
                    JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                    JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                    JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                    JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                    JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                    JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                    -- Join to get actual environment name for this iteration and role
                    LEFT JOIN environments_env_x_iterations_ite eei ON eei.ite_id = ite.ite_id AND eei.enr_id = sti.enr_id
                    LEFT JOIN environments_env env ON eei.env_id = env.env_id
                    -- Join to get impacted teams  
                    LEFT JOIN steps_master_stm_x_teams_tms_impacted impacted_rel ON stm.stm_id = impacted_rel.stm_id
                    LEFT JOIN teams_tms impacted_team ON impacted_rel.tms_id = impacted_team.tms_id
                    WHERE sti.sti_id = :stepInstanceId
                    GROUP BY sti.sti_id, sti.sti_name, sti.sti_status, sti.stm_id, sti.sti_duration_minutes,
                             stm.stt_code, stm.stm_number, stm.tms_id_owner, stm.stm_description,
                             mig.mig_name, ite.ite_name, plm.plm_name, owner_team.tms_name,
                             enr.enr_name, env.env_name
                ''', [stepInstanceId: stepInstanceId])
                
                if (!stepInstance) {
                    return [success: false, error: "Step instance not found"]
                }
                
                // Complete instruction directly with audit logging
                def updateCount = sql.executeUpdate('''
                    UPDATE instructions_instance_ini 
                    SET 
                        ini_is_completed = true,
                        ini_completed_at = CURRENT_TIMESTAMP,
                        usr_id_completed_by = :userId,
                        updated_at = CURRENT_TIMESTAMP,
                        updated_by = :updatedBy
                    WHERE ini_id = :iniId AND ini_is_completed = false
                ''', [iniId: instructionId, userId: userId, updatedBy: AuthenticationService.getSystemUser()])
                
                if (updateCount != 1) {
                    return [success: false, error: "Failed to complete instruction"]
                }
                
                // Log to audit trail if update was successful
                try {
                    println "StepRepository: Attempting to log instruction completion audit for iniId=${instructionId}, userId=${userId}, stepId=${stepInstanceId}"
                    
                    // Inline audit logging to avoid class loading issues
                    def auditDetails = groovy.json.JsonOutput.toJson([
                        step_instance_id: stepInstanceId.toString(),
                        completion_timestamp: new Date().format('yyyy-MM-dd HH:mm:ss')
                    ])
                    
                    sql.execute("""
                        INSERT INTO audit_log_aud (
                            usr_id, aud_action, aud_entity_type, aud_entity_id, aud_details
                        ) VALUES (?, ?, ?, ?, ?::jsonb)
                    """, [
                        userId,
                        'INSTRUCTION_COMPLETED',
                        'INSTRUCTION_INSTANCE',
                        instructionId,
                        auditDetails
                    ])
                    
                    println "StepRepository: Successfully logged instruction completion audit for iniId=${instructionId}"
                } catch (Exception auditError) {
                    // Audit logging failure shouldn't break the main flow
                    println "StepRepository: Failed to log instruction completion audit - ${auditError.message}"
                    auditError.printStackTrace()
                }
                
                // Get teams for notification - including instruction team
                def teams = getTeamsForNotificationWithInstructionTeam(
                    sql, 
                    stepInstance.stm_id as UUID, 
                    stepInstance.tms_id_owner as Integer,
                    instruction.instruction_team_id as Integer
                )
                
                // NOTE: Email notification is handled by StepNotificationIntegration.groovy
                // This eliminates duplicate email sending for instruction completion
                // StepNotificationIntegration.completeInstructionWithEnhancedNotifications()
                // calls this method and then sends its own enhanced notification
                println "[NOTIFICATION] Email notification will be handled by StepNotificationIntegration.groovy"
                
                return [success: true, emailsSent: teams.size()]
                
            } catch (Exception e) {
                return [success: false, error: e.message]
            }
        }
    }

    /**
     * Mark an instruction as incomplete and send notification to relevant teams.
     * @param instructionId The UUID of the instruction instance
     * @param stepInstanceId The UUID of the step instance
     * @param userId Optional user ID for audit logging
     * @return Map with success status and email send results
     */
    Map uncompleteInstructionWithNotification(UUID instructionId, UUID stepInstanceId, Integer userId = null) {
        DatabaseUtil.withSql { sql ->
            try {
                // Get instruction data
                def instruction = sql.firstRow('''
                    SELECT 
                        ini.ini_id, ini.ini_is_completed,
                        inm.inm_order, inm.inm_body as ini_name,
                        inm.tms_id as instruction_team_id
                    FROM instructions_instance_ini ini
                    JOIN instructions_master_inm inm ON ini.inm_id = inm.inm_id
                    WHERE ini.ini_id = :instructionId
                ''', [instructionId: instructionId])
                
                if (!instruction) {
                    return [success: false, error: "Instruction not found"]
                }
                
                // Check if already incomplete
                if (!instruction.ini_is_completed) {
                    return [success: false, error: "Instruction is already incomplete"]
                }
                
                // Get step instance data with all fields needed for email templates
                def stepInstance = sql.firstRow('''
                    SELECT 
                        sti.sti_id, sti.sti_name, sti.stm_id, sti.sti_duration_minutes,
                        stm.stt_code as sti_code, stm.stm_number, stm.tms_id_owner, stm.stm_description as sti_description,
                        mig.mig_name as migration_name,
                        ite.ite_name as iteration_name,
                        plm.plm_name as plan_name,
                        owner_team.tms_name as team_name,
                        -- Environment information
                        enr.enr_name as environment_role_name,
                        env.env_name as environment_name,
                        -- Impacted teams (comma-separated list)
                        COALESCE(
                            STRING_AGG(impacted_team.tms_name, ', ' ORDER BY impacted_team.tms_name), 
                            ''
                        ) as impacted_teams,
                        -- Recent comments (for email template) - simple empty list for compatibility
                        '' as recentComments
                    FROM steps_instance_sti sti
                    JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                    LEFT JOIN teams_tms owner_team ON stm.tms_id_owner = owner_team.tms_id
                    LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id
                    JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                    JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                    JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                    JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                    JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                    JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                    -- Join to get actual environment name for this iteration and role
                    LEFT JOIN environments_env_x_iterations_ite eei ON eei.ite_id = ite.ite_id AND eei.enr_id = sti.enr_id
                    LEFT JOIN environments_env env ON eei.env_id = env.env_id
                    -- Join to get impacted teams  
                    LEFT JOIN steps_master_stm_x_teams_tms_impacted impacted_rel ON stm.stm_id = impacted_rel.stm_id
                    LEFT JOIN teams_tms impacted_team ON impacted_rel.tms_id = impacted_team.tms_id
                    WHERE sti.sti_id = :stepInstanceId
                    GROUP BY sti.sti_id, sti.sti_name, sti.sti_status, sti.stm_id, sti.sti_duration_minutes,
                             stm.stt_code, stm.stm_number, stm.tms_id_owner, stm.stm_description,
                             mig.mig_name, ite.ite_name, plm.plm_name, owner_team.tms_name,
                             enr.enr_name, env.env_name
                ''', [stepInstanceId: stepInstanceId])
                
                if (!stepInstance) {
                    return [success: false, error: "Step instance not found"]
                }
                
                // Uncomplete instruction directly with audit logging
                // First, get the current user info for audit logging
                def instructionInfo = sql.firstRow('''
                    SELECT usr_id_completed_by 
                    FROM instructions_instance_ini 
                    WHERE ini_id = :iniId AND ini_is_completed = true
                ''', [iniId: instructionId])
                
                def updateCount = sql.executeUpdate('''
                    UPDATE instructions_instance_ini 
                    SET 
                        ini_is_completed = false,
                        ini_completed_at = NULL,
                        usr_id_completed_by = NULL,
                        updated_at = CURRENT_TIMESTAMP,
                        updated_by = :updatedBy
                    WHERE ini_id = :iniId AND ini_is_completed = true
                ''', [iniId: instructionId, updatedBy: AuthenticationService.getSystemUser()])
                
                if (updateCount != 1) {
                    return [success: false, error: "Failed to mark instruction as incomplete"]
                }
                
                // Log to audit trail if update was successful
                try {
                    // Use the original completing user ID or provided userId for audit logging
                    def auditUserId = instructionInfo?.usr_id_completed_by as Integer ?: userId
                    println "StepRepository: Attempting to log instruction uncompletion audit for iniId=${instructionId}, auditUserId=${auditUserId}, stepId=${stepInstanceId}"
                    
                    // Inline audit logging to avoid class loading issues
                    def auditDetails = groovy.json.JsonOutput.toJson([
                        step_instance_id: stepInstanceId.toString(),
                        uncomplete_timestamp: new Date().format('yyyy-MM-dd HH:mm:ss')
                    ])
                    
                    sql.execute("""
                        INSERT INTO audit_log_aud (
                            usr_id, aud_action, aud_entity_type, aud_entity_id, aud_details
                        ) VALUES (?, ?, ?, ?, ?::jsonb)
                    """, [
                        auditUserId,
                        'INSTRUCTION_UNCOMPLETED',
                        'INSTRUCTION_INSTANCE',
                        instructionId,
                        auditDetails
                    ])
                    
                    println "StepRepository: Successfully logged instruction uncompletion audit for iniId=${instructionId}"
                } catch (Exception auditError) {
                    // Audit logging failure shouldn't break the main flow
                    println "StepRepository: Failed to log instruction uncompletion audit - ${auditError.message}"
                    auditError.printStackTrace()
                }
                
                // Get teams for notification - including instruction team
                def teams = getTeamsForNotificationWithInstructionTeam(
                    sql, 
                    stepInstance.stm_id as UUID, 
                    stepInstance.tms_id_owner as Integer,
                    instruction.instruction_team_id as Integer
                )
                
                // Send notification
                EnhancedEmailService.sendInstructionUncompletedNotificationWithUrl(
                    instruction as Map,
                    stepInstance as Map,
                    teams,
                    userId
                )
                
                return [success: true, emailsSent: teams.size()]
                
            } catch (Exception e) {
                return [success: false, error: e.message]
            }
        }
    }

    /**
     * Helper method to get all teams that should receive notifications for a step.
     * Includes owner team and impacted teams.
     */
    private List<Map> getTeamsForNotification(Sql sql, UUID stmId, Integer ownerTeamId) {
        def teams = []
        
        // Add owner team
        if (ownerTeamId) {
            def ownerTeam = sql.firstRow('''
                SELECT tms_id, tms_name, tms_email
                FROM teams_tms
                WHERE tms_id = :teamId
            ''', [teamId: ownerTeamId])
            
            if (ownerTeam) {
                teams.add(ownerTeam as Map)
            }
        }
        
        // Add impacted teams
        def impactedTeams = sql.rows('''
            SELECT DISTINCT t.tms_id, t.tms_name, t.tms_email
            FROM teams_tms t
            JOIN steps_master_stm_x_teams_tms_impacted sti ON t.tms_id = sti.tms_id
            WHERE sti.stm_id = :stmId
        ''', [stmId: stmId])
        
        teams.addAll(impactedTeams as List<Map>)
        
        // Remove duplicates by team ID
        def uniqueTeams = teams.unique { team -> (team as Map).tms_id }
        
        return uniqueTeams as List<Map>
    }
    
    /**
     * Helper method to get all teams that should receive notifications for a step,
     * including the instruction-specific team.
     * Includes owner team, impacted teams, and instruction team.
     */
    private List<Map> getTeamsForNotificationWithInstructionTeam(Sql sql, UUID stmId, Integer ownerTeamId, Integer instructionTeamId) {
        def teams = []
        
        // Add owner team
        if (ownerTeamId) {
            def ownerTeam = sql.firstRow('''
                SELECT tms_id, tms_name, tms_email
                FROM teams_tms
                WHERE tms_id = :teamId
            ''', [teamId: ownerTeamId])
            
            if (ownerTeam) {
                teams.add(ownerTeam as Map)
            }
        }
        
        // Add impacted teams
        def impactedTeams = sql.rows('''
            SELECT DISTINCT t.tms_id, t.tms_name, t.tms_email
            FROM teams_tms t
            JOIN steps_master_stm_x_teams_tms_impacted sti ON t.tms_id = sti.tms_id
            WHERE sti.stm_id = :stmId
        ''', [stmId: stmId])
        
        teams.addAll(impactedTeams as List<Map>)
        
        // Add instruction team if different from owner and impacted teams
        if (instructionTeamId) {
            def instructionTeam = sql.firstRow('''
                SELECT tms_id, tms_name, tms_email
                FROM teams_tms
                WHERE tms_id = :teamId
            ''', [teamId: instructionTeamId])
            
            if (instructionTeam) {
                teams.add(instructionTeam as Map)
            }
        }
        
        // Remove duplicates by team ID
        def uniqueTeams = teams.unique { team -> (team as Map).tms_id }
        
        return uniqueTeams as List<Map>
    }
    
    /**
     * Find step instance details by step instance ID (UUID)
     * @param stepInstanceId Step instance UUID
     * @return Step instance details with instructions and comments
     */
    def findStepInstanceDetailsById(UUID stepInstanceId) {
        DatabaseUtil.withSql { Sql sql ->
            // Get the step instance with master data and hierarchy
            def stepInstance = sql.firstRow('''
                SELECT 
                    sti.sti_id,
                    sti.sti_name,
                    sti.sti_status,
                    sti.sti_duration_minutes,
                    sti.phi_id,
                    sti.enr_id,
                    enr.enr_name as environment_role_name,
                    env.env_name as environment_name,
                    stm.stm_id,
                    stm.stt_code,
                    stm.stm_number,
                    stm.stm_name,
                    stm.stm_description,
                    stm.stm_duration_minutes as master_duration,
                    stm.tms_id_owner,
                    owner_team.tms_name as owner_team_name,
                    stm.stm_id_predecessor,
                    -- Predecessor step info
                    pred_stm.stt_code as predecessor_stt_code,
                    pred_stm.stm_number as predecessor_stm_number,
                    pred_stm.stm_name as predecessor_name,
                    -- Hierarchy data
                    mig.mig_name as migration_name,
                    ite.ite_name as iteration_name,
                    plm.plm_name as plan_name,
                    sqm.sqm_name as sequence_name,
                    phm.phm_name as phase_name
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN teams_tms owner_team ON stm.tms_id_owner = owner_team.tms_id
                LEFT JOIN steps_master_stm pred_stm ON stm.stm_id_predecessor = pred_stm.stm_id
                LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id
                -- Join to get hierarchy
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN phases_master_phm phm ON phi.phm_id = phm.phm_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN sequences_master_sqm sqm ON sqi.sqm_id = sqm.sqm_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                -- Join to get actual environment name for this iteration and role
                LEFT JOIN environments_env_x_iterations_ite eei ON eei.ite_id = ite.ite_id AND eei.enr_id = sti.enr_id
                LEFT JOIN environments_env env ON eei.env_id = env.env_id
                WHERE sti.sti_id = :stepInstanceId
            ''', [stepInstanceId: stepInstanceId])
            
            if (!stepInstance) {
                return null
            }
            
            // Get instructions for this step instance with team information
            def instructions = sql.rows('''
                SELECT
                    ini.ini_id,
                    ini.ini_is_completed,
                    ini.ini_completed_at,
                    ini.usr_id_completed_by,
                    inm.inm_id,
                    inm.inm_order,
                    inm.inm_body,
                    inm.inm_duration_minutes,
                    inm.tms_id,
                    tms.tms_name as team_name,
                    tms.tms_email as team_email,
                    ctm.ctm_code as control_code
                FROM instructions_instance_ini ini
                JOIN instructions_master_inm inm ON ini.inm_id = inm.inm_id
                LEFT JOIN teams_tms tms ON inm.tms_id = tms.tms_id
                LEFT JOIN controls_master_ctm ctm ON inm.ctm_id = ctm.ctm_id
                WHERE ini.sti_id = :stepInstanceId
                ORDER BY inm.inm_order
            ''', [stepInstanceId: stepInstanceId])
            
            // Get iteration types (scope) for this step
            def iterationTypes = sql.rows('''
                SELECT itt.itt_code, itt.itt_name
                FROM steps_master_stm_x_iteration_types_itt smit
                JOIN iteration_types_itt itt ON smit.itt_code = itt.itt_code
                WHERE smit.stm_id = :stmId
                ORDER BY itt.itt_code
            ''', [stmId: stepInstance.stm_id])
            
            // Get impacted teams using the master step ID
            def impactedTeamIds = sql.rows('''
                SELECT tms_id
                FROM steps_master_stm_x_teams_tms_impacted
                WHERE stm_id = :stmId
            ''', [stmId: stepInstance.stm_id])*.tms_id
            
            def impactedTeams = []
            impactedTeamIds.each { teamId ->
                def team = sql.firstRow('SELECT tms_name FROM teams_tms WHERE tms_id = :teamId', [teamId: teamId])
                if (team) {
                    impactedTeams << team.tms_name
                }
            }
            
            // Get comments for this step instance
            def comments = findCommentsByStepInstanceId(stepInstanceId)
            
            // Get labels for this step (using master step ID)
            List labels = []
            if (stepInstance.stm_id) {
                try {
                    labels = findLabelsByStepId(stepInstance.stm_id as UUID) as List
                    println "DEBUG: Found ${labels.size()} labels for step ${stepInstance.stm_id}"
                } catch (Exception e) {
                    println "ERROR fetching labels: ${e.message}"
                }
            }
            
            return [
                stepSummary: [
                    ID: stepInstance.sti_id,
                    StepMasterID: stepInstance.stm_id,  // Added Step Master UUID for debugging
                    Name: stepInstance.sti_name ?: stepInstance.master_name,
                    Description: stepInstance.stm_description,
                    StatusID: stepInstance.sti_status,  // Changed from Status to StatusID for consistency
                    Duration: stepInstance.sti_duration_minutes ?: stepInstance.master_duration,
                    AssignedTeam: stepInstance.owner_team_name ?: 'Unassigned',
                    StepCode: "${stepInstance.stt_code}-${String.format('%03d', stepInstance.stm_number)}",
                    // Hierarchy information
                    MigrationName: stepInstance.migration_name,
                    IterationName: stepInstance.iteration_name,
                    PlanName: stepInstance.plan_name,
                    SequenceName: stepInstance.sequence_name,
                    PhaseName: stepInstance.phase_name,
                    // Predecessor information
                    PredecessorCode: stepInstance.predecessor_stt_code && stepInstance.predecessor_stm_number ?
                        "${stepInstance.predecessor_stt_code}-${String.format('%03d', stepInstance.predecessor_stm_number)}" : null,
                    PredecessorName: stepInstance.predecessor_name,
                    // Environment role
                    TargetEnvironment: stepInstance.environment_role_name ?
                        (stepInstance.environment_name ?
                            "${stepInstance.environment_role_name} (${stepInstance.environment_name})" :
                            "${stepInstance.environment_role_name} (!No Environment Assigned Yet!)") :
                        'Not specified',
                    // Iteration types (scope)
                    IterationTypes: iterationTypes.collect { it.itt_code },
                    // Labels
                    Labels: labels
                ],
                instructions: instructions.collect { instruction ->
                    [
                        ID: instruction.ini_id,
                        Description: instruction.inm_body,
                        IsCompleted: instruction.ini_is_completed,
                        CompletedAt: instruction.ini_completed_at,
                        CompletedBy: instruction.usr_id_completed_by,
                        Order: instruction.inm_order,
                        Duration: instruction.inm_duration_minutes,
                        TeamId: instruction.tms_id,
                        Team: instruction.team_name,
                        TeamEmail: instruction.team_email,
                        ControlCode: instruction.control_code  // BUGFIX: Include control code
                    ]
                },
                impactedTeams: impactedTeams,
                comments: comments
            ]
        }
    }

    /**
     * Find step instance details with instructions for the iteration view
     * @param stepCode The step code (e.g., "APP-001")
     * @return Map containing step instance details and instructions
     */
    def findStepInstanceDetailsByCode(String stepCode) {
        DatabaseUtil.withSql { Sql sql ->
            if (!stepCode || !stepCode.contains('-')) {
                return null
            }
            
            def parts = stepCode.split('-')
            if (parts.length != 2) {
                return null
            }
            def sttCode = parts[0]
            def stmNumber = Integer.parseInt(parts[1])
            
            // First find the step master
            def stepMaster = sql.firstRow('''
                SELECT stm.stm_id, stm.stt_code, stm.stm_number, stm.stm_name, stm.stm_description, stm.stm_duration_minutes, stm.tms_id_owner
                FROM steps_master_stm stm
                WHERE stm.stt_code = :sttCode AND stm.stm_number = :stmNumber
            ''', [sttCode: sttCode, stmNumber: stmNumber])
            
            if (!stepMaster) {
                return null
            }
            
            // Find the most recent step instance WITH complete hierarchical context
            def stepInstance = sql.firstRow('''
                SELECT 
                    sti.sti_id,
                    sti.sti_name,
                    sti.sti_status,
                    sti.sti_duration_minutes,
                    sti.phi_id,
                    sti.enr_id,
                    -- Team information (FIXED JOIN)
                    tms.tms_name as owner_team_name,
                    -- Status information (FIXED)
                    sts.sts_name as status_name,
                    -- Complete hierarchical context
                    mig.mig_name as migration_name,
                    ite.ite_name as iteration_name,
                    plm.plm_name as plan_name,
                    sqm.sqm_name as sequence_name,
                    phm.phm_name as phase_name,
                    -- Environment information
                    enr.enr_name as environment_role_name,
                    env.env_name as environment_name
                FROM steps_instance_sti sti
                -- FIXED: Add the missing steps_master join
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                -- FIXED: Proper team join using the actual foreign key
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                -- FIXED: Status name resolution
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                -- Complete hierarchy joins
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN phases_master_phm phm ON phi.phm_id = phm.phm_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN sequences_master_sqm sqm ON sqi.sqm_id = sqm.sqm_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                -- Environment joins
                LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id
                LEFT JOIN environments_env_x_iterations_ite eei ON eei.ite_id = ite.ite_id AND eei.enr_id = sti.enr_id
                LEFT JOIN environments_env env ON eei.env_id = env.env_id
                WHERE sti.stm_id = :stmId
                ORDER BY sti.sti_id DESC
                LIMIT 1
            ''', [stmId: stepMaster.stm_id])
            
            if (!stepInstance) {
                // If no instance exists, return master data only
                // Get owner team name for master
                def ownerTeam = null
                if (stepMaster.tms_id_owner) {
                    ownerTeam = sql.firstRow('SELECT tms_name FROM teams_tms WHERE tms_id = :teamId', [teamId: stepMaster.tms_id_owner])
                }
                
                return [
                    stepSummary: [
                        ID: stepCode,
                        Name: stepMaster.stm_name,
                        Description: stepMaster.stm_description,
                        StatusID: 1, // PENDING status ID
                        AssignedTeam: ownerTeam?.tms_name ?: 'Unassigned',
                        // Add empty hierarchical context for consistency
                        MigrationName: null,
                        IterationName: null,
                        PlanName: null,
                        SequenceName: null,
                        PhaseName: null,
                        Labels: []
                    ],
                    instructions: [],
                    impactedTeams: []
                ]
            }
            
            // Get instructions for this step instance with team information
            def instructions = sql.rows('''
                SELECT
                    ini.ini_id,
                    ini.ini_is_completed,
                    ini.ini_completed_at,
                    ini.usr_id_completed_by,
                    inm.inm_id,
                    inm.inm_order,
                    inm.inm_body,
                    inm.inm_duration_minutes,
                    inm.tms_id,
                    tms.tms_name as team_name,
                    tms.tms_email as team_email,
                    ctm.ctm_code as control_code
                FROM instructions_instance_ini ini
                JOIN instructions_master_inm inm ON ini.inm_id = inm.inm_id
                LEFT JOIN teams_tms tms ON inm.tms_id = tms.tms_id
                LEFT JOIN controls_master_ctm ctm ON inm.ctm_id = ctm.ctm_id
                WHERE ini.sti_id = :stiId
                ORDER BY inm.inm_order
            ''', [stiId: stepInstance.sti_id])
            
            // Get impacted teams using the master step ID
            def impactedTeamIds = sql.rows('''
                SELECT tms_id
                FROM steps_master_stm_x_teams_tms_impacted
                WHERE stm_id = :stmId
            ''', [stmId: stepMaster.stm_id])*.tms_id
            
            def impactedTeams = []
            impactedTeamIds.each { teamId ->
                def team = sql.firstRow('SELECT tms_name FROM teams_tms WHERE tms_id = :teamId', [teamId: teamId])
                if (team) {
                    impactedTeams << team.tms_name
                }
            }
            
            // Get comments for this step instance
            def comments = findCommentsByStepInstanceId(stepInstance.sti_id as UUID)
            
            // Get labels for this step (using master step ID) - ADDED
            List labels = []
            if (stepMaster.stm_id) {
                try {
                    labels = findLabelsByStepId(stepMaster.stm_id as UUID) as List
                    println "DEBUG: Found ${labels.size()} labels for step ${stepMaster.stm_id}"
                } catch (Exception e) {
                    println "ERROR fetching labels: ${e.message}"
                }
            }
            
            return [
                stepSummary: [
                    ID: stepCode,
                    Name: stepInstance.sti_name ?: stepMaster.stm_name,
                    Description: stepMaster.stm_description,
                    // Changed to StatusID for consistency with findStepInstanceDetailsById
                    StatusID: stepInstance.sti_status,
                    AssignedTeam: stepInstance.owner_team_name ?: 'Unassigned',
                    Duration: stepMaster.stm_duration_minutes,
                    sti_id: stepInstance.sti_id?.toString(),  // Include step instance ID for comments
                    StepMasterID: stepMaster.stm_id?.toString(),  // Include step master ID for debugging
                    // ADDED: Complete hierarchical context
                    MigrationName: stepInstance.migration_name,
                    IterationName: stepInstance.iteration_name,
                    PlanName: stepInstance.plan_name,
                    SequenceName: stepInstance.sequence_name,
                    PhaseName: stepInstance.phase_name,
                    // ADDED: Environment context
                    TargetEnvironment: stepInstance.environment_role_name ? 
                        (stepInstance.environment_name ? 
                            "${stepInstance.environment_role_name} (${stepInstance.environment_name})" : 
                            "${stepInstance.environment_role_name} (!No Environment Assigned Yet!)") : 
                        'Not specified',
                    // ADDED: Labels
                    Labels: labels
                ],
                instructions: instructions.collect { instruction ->
                    [
                        ID: instruction.ini_id?.toString(),
                        ini_id: instruction.ini_id?.toString(),
                        Order: instruction.inm_order,
                        Description: instruction.inm_body,
                        Duration: instruction.inm_duration_minutes,
                        IsCompleted: instruction.ini_is_completed ?: false,
                        CompletedAt: instruction.ini_completed_at,
                        CompletedBy: instruction.usr_id_completed_by,
                        TeamId: instruction.tms_id,
                        Team: instruction.team_name,
                        TeamEmail: instruction.team_email,
                        ControlCode: instruction.control_code
                    ]
                },
                impactedTeams: impactedTeams,
                comments: comments
            ]
        }
    }
    
    /**
     * Fetch comments for a step instance
     * @param stepInstanceId The UUID of the step instance
     * @return List of comments with user information
     */
    def findCommentsByStepInstanceId(UUID stepInstanceId) {
        DatabaseUtil.withSql { Sql sql ->
            def comments = sql.rows('''
                SELECT 
                    sic.sic_id,
                    sic.sti_id,
                    sic.comment_body,
                    sic.created_at,
                    sic.updated_at,
                    u.usr_id,
                    u.usr_first_name,
                    u.usr_last_name,
                    u.usr_email,
                    t.tms_name as user_team_name
                FROM step_instance_comments_sic sic
                JOIN users_usr u ON sic.created_by = u.usr_id
                LEFT JOIN teams_tms_x_users_usr tmu ON u.usr_id = tmu.usr_id
                LEFT JOIN teams_tms t ON tmu.tms_id = t.tms_id
                WHERE sic.sti_id = :stepInstanceId
                ORDER BY sic.created_at DESC
            ''', [stepInstanceId: stepInstanceId])
            
            return comments.collect { comment ->
                [
                    id: comment.sic_id,
                    body: comment.comment_body,
                    createdAt: comment.created_at,
                    updatedAt: comment.updated_at,
                    author: [
                        id: comment.usr_id,
                        name: "${comment.usr_first_name} ${comment.usr_last_name}".trim(),
                        email: comment.usr_email,
                        team: comment.user_team_name
                    ]
                ]
            }
        }
    }
    
    /**
     * Create a new comment for a step instance
     * @param stepInstanceId The UUID of the step instance
     * @param commentBody The comment text
     * @param userId The ID of the user creating the comment
     * @return The created comment with ID
     */
    def createComment(UUID stepInstanceId, String commentBody, Integer userId) {
        DatabaseUtil.withSql { Sql sql ->
            def result = sql.firstRow('''
                INSERT INTO step_instance_comments_sic (sti_id, comment_body, created_by)
                VALUES (:stepInstanceId, :commentBody, CASE WHEN :userId IS NULL THEN 57 ELSE :userId END)
                RETURNING sic_id, created_at
            ''', [stepInstanceId: stepInstanceId, commentBody: commentBody, userId: userId])
            
            return [
                id: result.sic_id,
                createdAt: result.created_at
            ]
        }
    }
    
    /**
     * Update an existing comment
     * @param commentId The ID of the comment to update
     * @param commentBody The new comment text
     * @param userId The ID of the user updating the comment
     * @return Success status
     */
    def updateComment(Integer commentId, String commentBody, Integer userId) {
        DatabaseUtil.withSql { Sql sql ->
            def updateCount = sql.executeUpdate('''
                UPDATE step_instance_comments_sic 
                SET comment_body = :commentBody,
                    updated_by = CASE WHEN :userId IS NULL THEN 57 ELSE :userId END,
                    updated_at = CURRENT_TIMESTAMP
                WHERE sic_id = :commentId
            ''', [commentId: commentId, commentBody: commentBody, userId: userId])
            
            return updateCount == 1
        }
    }
    
    /**
     * Delete a comment
     * @param commentId The ID of the comment to delete
     * @param userId The ID of the user attempting to delete (for permission check)
     * @return Success status
     */
    def deleteComment(Integer commentId, Integer userId) {
        DatabaseUtil.withSql { Sql sql ->
            // For now, we'll allow any user to delete any comment
            // In production, you'd want to check if the user created the comment or has admin rights
            def deleteCount = sql.executeUpdate('''
                DELETE FROM step_instance_comments_sic 
                WHERE sic_id = :commentId
            ''', [commentId: commentId])
            
            return deleteCount == 1
        }
    }
    
    /**
     * Enriches step instance data with status metadata while maintaining backward compatibility.
     * @param row Database row containing step instance data
     * @return Enhanced step instance map with statusMetadata
     */
    private Map enrichStepInstanceWithStatusMetadata(Map row) {
        // Get status metadata if status is an ID
        def statusMetadata = null
        def statusName = row.sti_status
        
        if (row.sti_status instanceof Number) {
            // Status is already an ID, get the name and metadata
            def statusInfo = DatabaseUtil.withSql { sql ->
                sql.firstRow("SELECT sts_name, sts_color, sts_type FROM status_sts WHERE sts_id = :statusId", 
                    [statusId: row.sti_status])
            }
            if (statusInfo) {
                statusName = statusInfo.sts_name
                statusMetadata = [
                    id: row.sti_status,
                    name: statusInfo.sts_name,
                    color: statusInfo.sts_color,
                    type: statusInfo.sts_type
                ]
            }
        }
        
        return [
            id: row.sti_id,
            stmId: row.stm_id,
            sttCode: row.stt_code,
            stmNumber: row.stm_number,
            name: row.sti_name ?: row.master_name,
            status: statusName, // Backward compatibility - return status name as string
            durationMinutes: row.sti_duration_minutes,
            ownerTeamId: row.tms_id_owner,
            ownerTeamName: row.owner_team_name,
            // Hierarchy context
            sequenceId: row.sqm_id,
            sequenceName: row.sqm_name,
            sequenceNumber: row.sqm_order,
            phaseId: row.phm_id,
            phaseName: row.phm_name,
            phaseNumber: row.phm_order,
            planId: row.plm_id,
            planName: row.plm_name,
            iterationId: row.ite_id,
            iterationName: row.ite_name,
            migrationId: row.mig_id,
            migrationName: row.mig_name,
            // Enhanced status metadata
            statusMetadata: statusMetadata
        ] as Map
    }

    // ==================== MODERN SPRINT 3 PATTERNS ====================
    
    /**
     * Advanced query method with comprehensive filtering, sorting, and pagination.
     * Following Sprint 3 patterns from SequenceRepository.groovy.
     * @param filters Map containing optional filters
     * @param limit Maximum number of results (max 1000, default 100)
     * @param offset Number of results to skip (default 0)
     * @param sortBy Field to sort by (default: stm_number)
     * @param sortOrder Sort direction ('ASC' or 'DESC', default 'ASC')
     * @return Map containing steps data and pagination metadata
     */
    Map findStepsWithFilters(Map filters, Integer limit = 100, Integer offset = 0, 
                            String sortBy = 'stm_number', String sortOrder = 'ASC') {
        DatabaseUtil.withSql { sql ->
            // Validate and sanitize parameters (ADR-031 type safety)
            limit = Math.min(limit ?: 100, 1000) as Integer
            offset = Math.max(offset ?: 0, 0) as Integer
            sortBy = sanitizeSortField(sortBy)
            sortOrder = (sortOrder?.toUpperCase() in ['ASC', 'DESC']) ? sortOrder.toUpperCase() : 'ASC'
            
            def baseQuery = '''
                SELECT 
                    -- Step instance data
                    sti.sti_id, stm.stt_code, stm.stm_number, sti.sti_name, sti.sti_status, 
                    sti.sti_duration_minutes, stm.tms_id_owner, sti.sti_start_time, sti.sti_end_time,
                    -- Master step data
                    stm.stm_id, stm.stm_name, stm.stm_description,
                    -- Sequence and phase hierarchy
                    sqm.sqm_id, sqm.sqm_name, sqm.sqm_order,
                    phm.phm_id, phm.phm_name, phm.phm_order,
                    -- Plan hierarchy
                    plm.plm_id, plm.plm_name,
                    -- Instance hierarchy
                    pli.pli_id, sqi.sqi_id, phi.phi_id,
                    -- Team owner information
                    tms.tms_name as owner_team_name,
                    -- Iteration and migration context
                    ite.ite_id, ite.ite_name,
                    mig.mig_id, mig.mig_name,
                    -- Status metadata
                    sts.sts_name as status_name, sts.sts_color, sts.sts_type,
                    -- Count for pagination
                    COUNT(*) OVER() as total_count
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN phases_master_phm phm ON phi.phm_id = phm.phm_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN sequences_master_sqm sqm ON sqi.sqm_id = sqm.sqm_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                WHERE 1=1
            '''
            
            def params = [:]
            
            // Add hierarchical filters (ADR-030 compliance - use instance IDs)
            if (filters.migrationId) {
                baseQuery += ' AND mig.mig_id = :migrationId'
                params.migrationId = UUID.fromString(filters.migrationId as String)
            }
            
            if (filters.iterationId) {
                baseQuery += ' AND ite.ite_id = :iterationId'
                params.iterationId = UUID.fromString(filters.iterationId as String)
            }
            
            if (filters.planInstanceId) {
                baseQuery += ' AND pli.pli_id = :planInstanceId'
                params.planInstanceId = UUID.fromString(filters.planInstanceId as String)
            }
            
            if (filters.sequenceInstanceId) {
                baseQuery += ' AND sqi.sqi_id = :sequenceInstanceId'
                params.sequenceInstanceId = UUID.fromString(filters.sequenceInstanceId as String)
            }
            
            if (filters.phaseInstanceId) {
                baseQuery += ' AND phi.phi_id = :phaseInstanceId'
                params.phaseInstanceId = UUID.fromString(filters.phaseInstanceId as String)
            }
            
            // Entity filtering
            if (filters.teamId) {
                baseQuery += ' AND stm.tms_id_owner = :teamId'
                params.teamId = Integer.parseInt(filters.teamId as String)
            }
            
            if (filters.statusId) {
                baseQuery += ' AND sti.sti_status = :statusId'
                params.statusId = Integer.parseInt(filters.statusId as String)
            }
            
            if (filters.stepTypeCode) {
                baseQuery += ' AND stm.stt_code = :stepTypeCode'
                params.stepTypeCode = filters.stepTypeCode as String
            }
            
            // Label filtering (through join table)
            if (filters.labelId) {
                baseQuery += '''
                    AND EXISTS (
                        SELECT 1 FROM labels_lbl_x_steps_master_stm lxs 
                        WHERE lxs.stm_id = stm.stm_id AND lxs.lbl_id = :labelId
                    )
                '''
                params.labelId = Integer.parseInt(filters.labelId as String)
            }
            
            // Search capabilities
            if (filters.searchText) {
                baseQuery += '''
                    AND (UPPER(stm.stm_name) LIKE UPPER(:searchText) 
                         OR UPPER(stm.stm_description) LIKE UPPER(:searchText)
                         OR UPPER(sti.sti_name) LIKE UPPER(:searchText))
                '''
                params.searchText = "%${filters.searchText as String}%"
            }
            
            // Add sorting and pagination
            def orderClause = "ORDER BY ${sortBy} ${sortOrder}, stm.stm_number ASC"
            def paginationClause = "LIMIT :limit OFFSET :offset"
            
            params.limit = limit
            params.offset = offset
            
            def finalQuery = "${baseQuery} ${orderClause} ${paginationClause}"
            
            def results = sql.rows(finalQuery, params)
            def totalCount = results.isEmpty() ? 0 : (results[0].total_count as Integer)
            
            // Transform results with status metadata enrichment
            def enrichedSteps = results.collect { row ->
                enrichStepInstanceWithAdvancedMetadata(row)
            }
            
            return [
                steps: enrichedSteps,
                pagination: [
                    totalCount: totalCount,
                    limit: limit,
                    offset: offset,
                    hasMore: (offset + limit) < totalCount,
                    pageCount: Math.ceil(totalCount / (double) limit) as Integer
                ],
                filters: filters,
                sorting: [
                    sortBy: sortBy,
                    sortOrder: sortOrder
                ]
            ]
        }
    }
    
    /**
     * Gets summary statistics for steps by migration.
     * Following Sprint 3 aggregation patterns.
     * @param migrationId The UUID of the migration
     * @return Map containing step counts by various dimensions
     */
    Map getStepsSummary(UUID migrationId) {
        DatabaseUtil.withSql { sql ->
            def summaryData = [:]
            
            // Overall step counts
            def overallCounts = sql.firstRow('''
                SELECT 
                    COUNT(*) as total_steps,
                    COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) as completed_steps,
                    COUNT(CASE WHEN sts.sts_name = '${getInProgressStepStatus()}' THEN 1 END) as in_progress_steps,
                    COUNT(CASE WHEN sts.sts_name = 'PENDING' THEN 1 END) as pending_steps,
                    COUNT(CASE WHEN sts.sts_name = '${getOpenStepStatus()}' THEN 1 END) as open_steps,
                    AVG(stm.stm_duration_minutes) as avg_duration_minutes
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                WHERE ite.mig_id = :migrationId
            ''', [migrationId: migrationId])
            
            summaryData.overall = overallCounts
            
            // Steps by team
            def teamCounts = sql.rows('''
                SELECT 
                    tms.tms_name,
                    COUNT(*) as step_count,
                    COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) as completed_count
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                WHERE ite.mig_id = :migrationId
                GROUP BY tms.tms_name
                ORDER BY step_count DESC
            ''', [migrationId: migrationId])
            
            summaryData.byTeam = teamCounts
            
            // Steps by phase
            def phaseCounts = sql.rows('''
                SELECT 
                    phm.phm_name,
                    phm.phm_order,
                    COUNT(*) as step_count,
                    COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) as completed_count,
                    AVG(stm.stm_duration_minutes) as avg_duration_minutes
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN phases_master_phm phm ON phi.phm_id = phm.phm_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                WHERE ite.mig_id = :migrationId
                GROUP BY phm.phm_name, phm.phm_order
                ORDER BY phm.phm_order
            ''', [migrationId: migrationId])
            
            summaryData.byPhase = phaseCounts
            
            // Steps by step type
            def typeCounts = sql.rows('''
                SELECT 
                    stm.stt_code,
                    COUNT(*) as step_count,
                    COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) as completed_count
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                WHERE ite.mig_id = :migrationId
                GROUP BY stm.stt_code
                ORDER BY step_count DESC
            ''', [migrationId: migrationId])
            
            summaryData.byType = typeCounts
            
            return summaryData
        }
    }
    
    /**
     * Gets progress tracking metrics for steps by migration.
     * @param migrationId The UUID of the migration
     * @return Map containing progress metrics and bottleneck analysis
     */
    Map getStepsProgress(UUID migrationId) {
        DatabaseUtil.withSql { sql ->
            def progressData = [:]
            
            // Overall progress metrics
            def progressMetrics = sql.firstRow('''
                SELECT 
                    COUNT(*) as total_steps,
                    COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) as completed_steps,
                    ROUND((COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) * 100.0 / COUNT(*)), 2) as completion_percentage,
                    SUM(stm.stm_duration_minutes) as total_estimated_minutes,
                    SUM(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN stm.stm_duration_minutes ELSE 0 END) as completed_minutes,
                    MIN(sti.sti_start_time) as earliest_start,
                    MAX(sti.sti_end_time) as latest_completion
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                WHERE ite.mig_id = :migrationId
            ''', [migrationId: migrationId])
            
            progressData.overall = progressMetrics
            
            // Bottleneck analysis - steps taking longer than expected
            def bottlenecks = sql.rows('''
                SELECT 
                    sti.sti_id,
                    stm.stt_code || '-' || LPAD(stm.stm_number::text, 3, '0') as step_code,
                    stm.stm_name,
                    tms.tms_name as owner_team,
                    stm.stm_duration_minutes as estimated_minutes,
                    EXTRACT(EPOCH FROM (sti.sti_end_time - sti.sti_start_time))/60 as actual_minutes,
                    sts.sts_name as current_status
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                WHERE ite.mig_id = :migrationId
                    AND sti.sti_start_time IS NOT NULL
                    AND (sts.sts_name = '${getInProgressStepStatus()}' OR sti.sti_end_time IS NOT NULL)
                    AND (
                        (sti.sti_end_time IS NULL AND EXTRACT(EPOCH FROM (NOW() - sti.sti_start_time))/60 > stm.stm_duration_minutes * 1.5)
                        OR 
                        (sti.sti_end_time IS NOT NULL AND EXTRACT(EPOCH FROM (sti.sti_end_time - sti.sti_start_time))/60 > stm.stm_duration_minutes * 1.2)
                    )
                ORDER BY 
                    CASE 
                        WHEN sti.sti_end_time IS NULL THEN EXTRACT(EPOCH FROM (NOW() - sti.sti_start_time))/60 - stm.stm_duration_minutes
                        ELSE EXTRACT(EPOCH FROM (sti.sti_end_time - sti.sti_start_time))/60 - stm.stm_duration_minutes
                    END DESC
                LIMIT 10
            ''', [migrationId: migrationId])
            
            progressData.bottlenecks = bottlenecks
            
            // Phase progress breakdown
            def phaseProgress = sql.rows('''
                SELECT 
                    phm.phm_name,
                    phm.phm_order,
                    COUNT(*) as total_steps,
                    COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) as completed_steps,
                    ROUND((COUNT(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN 1 END) * 100.0 / COUNT(*)), 2) as completion_percentage,
                    SUM(stm.stm_duration_minutes) as total_estimated_minutes,
                    SUM(CASE WHEN sts.sts_name = '${getCompletedStepStatus()}' THEN stm.stm_duration_minutes ELSE 0 END) as completed_minutes
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                LEFT JOIN status_sts sts ON sti.sti_status = sts.sts_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN phases_master_phm phm ON phi.phm_id = phm.phm_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                WHERE ite.mig_id = :migrationId
                GROUP BY phm.phm_name, phm.phm_order
                ORDER BY phm.phm_order
            ''', [migrationId: migrationId])
            
            progressData.phaseProgress = phaseProgress
            
            return progressData
        }
    }
    
    /**
     * Bulk update step instance status with transaction safety.
     * @param stepIds List of step instance UUIDs
     * @param statusId Integer status ID
     * @param userId User ID for audit logging
     * @return Map with success status and update results
     */
    Map bulkUpdateStepStatus(List<UUID> stepIds, Integer statusId, Integer userId = null) {
        DatabaseUtil.withSql { sql ->
            return sql.withTransaction {
                try {
                    // Validate status exists
                    def status = sql.firstRow("SELECT sts_name FROM status_sts WHERE sts_id = :statusId AND sts_type = 'Step'", 
                        [statusId: statusId])
                    
                    if (!status) {
                        return [success: false, error: "Invalid status ID: ${statusId}"]
                    }
                    
                    def results = []
                    def successCount = 0
                    def errorCount = 0
                    
                    stepIds.each { stepId ->
                        try {
                            // Get current step data for notification with all fields needed for email templates
                            def stepInstance = sql.firstRow('''
                                SELECT 
                                    sti.sti_id, sti.sti_name, sti.stm_id, sti.sti_status, sti.sti_duration_minutes,
                                    stm.stt_code as sti_code, stm.stm_number, stm.tms_id_owner, stm.stm_description as sti_description,
                                    owner_team.tms_name as team_name
                                FROM steps_instance_sti sti
                                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                                LEFT JOIN teams_tms owner_team ON stm.tms_id_owner = owner_team.tms_id
                                WHERE sti.sti_id = :stepId
                            ''', [stepId: stepId])
                            
                            if (!stepInstance) {
                                results.add([stepId: stepId, success: false, error: "Step not found"])
                                errorCount++
                                return
                            }
                            
                            def oldStatusId = stepInstance.sti_status

                            // Calculate end time in Groovy to avoid PostgreSQL parameter type issues
                            def completedStatusName = getCompletedStepStatus()
                            def shouldSetEndTime = (status.sts_name == completedStatusName)
                            def endTime = shouldSetEndTime ? new java.sql.Timestamp(System.currentTimeMillis()) : null

                            // Update the status - PostgreSQL parameter type fix
                            def updateCount = sql.executeUpdate('''
                                UPDATE steps_instance_sti
                                SET sti_status = :statusId,
                                    sti_end_time = COALESCE(:endTime, sti_end_time),
                                    updated_by = CASE WHEN :userId IS NULL THEN 'confluence_user' ELSE CAST(:userId AS varchar) END,
                                    updated_at = CURRENT_TIMESTAMP
                                WHERE sti_id = :stepId
                            ''', [
                                statusId: statusId,
                                endTime: endTime,
                                userId: userId,
                                stepId: stepId
                            ])
                            
                            if (updateCount == 1) {
                                results.add([stepId: stepId, success: true, oldStatus: oldStatusId, newStatus: statusId])
                                successCount++
                            } else {
                                results.add([stepId: stepId, success: false, error: "Update failed"])
                                errorCount++
                            }
                            
                        } catch (Exception e) {
                            results.add([stepId: stepId, success: false, error: e.message])
                            errorCount++
                        }
                    }
                    
                    return [
                        success: errorCount == 0,
                        successCount: successCount,
                        errorCount: errorCount,
                        totalCount: stepIds.size(),
                        results: results,
                        newStatus: status.sts_name
                    ]
                    
                } catch (Exception e) {
                    return [success: false, error: "Bulk operation failed: ${e.message}"]
                }
            }
        }
    }
    
    /**
     * Bulk assign steps to a team with transaction safety.
     * @param stepIds List of step instance UUIDs (targets step master for assignment)
     * @param teamId Integer team ID
     * @param userId User ID for audit logging
     * @return Map with success status and assignment results
     */
    Map bulkAssignSteps(List<UUID> stepIds, Integer teamId, Integer userId = null) {
        DatabaseUtil.withSql { sql ->
            return sql.withTransaction {
                try {
                    // Validate team exists
                    def team = sql.firstRow("SELECT tms_name FROM teams_tms WHERE tms_id = :teamId", [teamId: teamId])
                    
                    if (!team) {
                        return [success: false, error: "Invalid team ID: ${teamId}"]
                    }
                    
                    def results = []
                    def successCount = 0
                    def errorCount = 0
                    
                    stepIds.each { stepId ->
                        try {
                            // Get step master ID from step instance
                            def stepData = sql.firstRow('''
                                SELECT sti.stm_id, stm.tms_id_owner as current_team_id
                                FROM steps_instance_sti sti
                                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                                WHERE sti.sti_id = :stepId
                            ''', [stepId: stepId])
                            
                            if (!stepData) {
                                results.add([stepId: stepId, success: false, error: "Step not found"])
                                errorCount++
                                return
                            }
                            
                            def oldTeamId = stepData.current_team_id
                            
                            // Update team assignment on master step
                            def updateCount = sql.executeUpdate('''
                                UPDATE steps_master_stm 
                                SET tms_id_owner = :teamId,
                                    updated_by = :userId,
                                    updated_at = CURRENT_TIMESTAMP
                                WHERE stm_id = :stmId
                            ''', [teamId: teamId, userId: userId ?: 'system', stmId: stepData.stm_id])
                            
                            if (updateCount == 1) {
                                results.add([stepId: stepId, success: true, oldTeamId: oldTeamId, newTeamId: teamId])
                                successCount++
                            } else {
                                results.add([stepId: stepId, success: false, error: "Update failed"])
                                errorCount++
                            }
                            
                        } catch (Exception e) {
                            results.add([stepId: stepId, success: false, error: e.message])
                            errorCount++
                        }
                    }
                    
                    return [
                        success: errorCount == 0,
                        successCount: successCount,
                        errorCount: errorCount,
                        totalCount: stepIds.size(),
                        results: results,
                        newTeam: team.tms_name
                    ]
                    
                } catch (Exception e) {
                    return [success: false, error: "Bulk assignment failed: ${e.message}"]
                }
            }
        }
    }
    
    /**
     * Bulk reorder steps within phases with transaction safety.
     * @param stepReorderData List of maps with stepId and newOrder
     * @return Map with success status and reorder results
     */
    Map bulkReorderSteps(List<Map> stepReorderData) {
        DatabaseUtil.withSql { sql ->
            return sql.withTransaction {
                try {
                    def results = []
                    def successCount = 0
                    def errorCount = 0
                    
                    // Group by phase for efficient reordering
                    def stepsByPhase = stepReorderData.groupBy { reorderItem ->
                        def stepData = sql.firstRow('''
                            SELECT phi.phi_id
                            FROM steps_instance_sti sti
                            JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                            WHERE sti.sti_id = :stepId
                        ''', [stepId: reorderItem.stepId])
                        return stepData?.phi_id
                    }
                    
                    stepsByPhase.each { phaseId, stepsInPhase ->
                        if (!phaseId) return
                        
                        try {
                            // Sort steps in this phase by new order
                            def sortedSteps = stepsInPhase.sort { it.newOrder as Integer }
                            
                            // Update each step's order
                            sortedSteps.eachWithIndex { reorderItem, index ->
                                def newOrder = index + 1 // 1-based ordering
                                
                                def updateCount = sql.executeUpdate('''
                                    UPDATE steps_master_stm 
                                    SET stm_number = :newOrder,
                                        updated_by = 'system',
                                        updated_at = CURRENT_TIMESTAMP
                                    WHERE stm_id = (
                                        SELECT sti.stm_id 
                                        FROM steps_instance_sti sti 
                                        WHERE sti.sti_id = :stepId
                                    )
                                ''', [newOrder: newOrder, stepId: reorderItem.stepId])
                                
                                if (updateCount == 1) {
                                    results.add([stepId: reorderItem.stepId, success: true, newOrder: newOrder])
                                    successCount++
                                } else {
                                    results.add([stepId: reorderItem.stepId, success: false, error: "Reorder failed"])
                                    errorCount++
                                }
                            }
                            
                        } catch (Exception e) {
                            stepsInPhase.each { reorderItem ->
                                results.add([stepId: reorderItem.stepId, success: false, error: e.message])
                                errorCount++
                            }
                        }
                    }
                    
                    return [
                        success: errorCount == 0,
                        successCount: successCount,
                        errorCount: errorCount,
                        totalCount: stepReorderData.size(),
                        results: results
                    ]
                    
                } catch (Exception e) {
                    return [success: false, error: "Bulk reorder failed: ${e.message}"]
                }
            }
        }
    }
    
    // ==================== HELPER METHODS ====================
    
    /**
     * Sanitizes sort field to prevent SQL injection.
     */
    private String sanitizeSortField(String sortBy) {
        def allowedFields = [
            'stm_number', 'sti_name', 'stm_name', 'sti_status', 
            'sti_duration_minutes', 'sqm_order', 'phm_order',
            'tms_name', 'sti_start_time', 'sti_end_time'
        ]
        return sortBy in allowedFields ? sortBy : 'stm_number'
    }
    
    /**
     * Enhanced step instance enrichment with advanced metadata.
     */
    private Map enrichStepInstanceWithAdvancedMetadata(Map row) {
        return [
            id: row.sti_id,
            stmId: row.stm_id,
            sttCode: row.stt_code,
            stmNumber: row.stm_number,
            stepCode: "${row.stt_code}-${String.format('%03d', row.stm_number)}",
            name: row.sti_name ?: row.master_name,
            description: row.stm_description,
            status: row.status_name ?: row.sti_status, // Backward compatibility
            statusMetadata: row.status_name ? [
                id: row.sti_status,
                name: row.status_name,
                color: row.sts_color,
                type: row.sts_type
            ] : null,
            durationMinutes: row.sti_duration_minutes,
            startTime: row.sti_start_time,
            endTime: row.sti_end_time,
            ownerTeamId: row.tms_id_owner,
            ownerTeamName: row.owner_team_name,
            // Hierarchy context
            sequenceId: row.sqm_id,
            sequenceName: row.sqm_name,
            sequenceOrder: row.sqm_order,
            phaseId: row.phm_id,
            phaseName: row.phm_name,
            phaseOrder: row.phm_order,
            planId: row.plm_id,
            planName: row.plm_name,
            // Instance IDs for hierarchical filtering
            planInstanceId: row.pli_id,
            sequenceInstanceId: row.sqi_id,
            phaseInstanceId: row.phi_id,
            iterationId: row.ite_id,
            iterationName: row.ite_name,
            migrationId: row.mig_id,
            migrationName: row.mig_name
        ] as Map
    }
    
    // ========================================
    // US-056-A: DTO-BASED REPOSITORY METHODS
    // ========================================
    
    /**
     * Import the transformation service for DTO conversion
     */
    private static getTransformationService() {
        return new umig.service.StepDataTransformationService()
    }
    
    // ========================================
    // MASTER DTO METHODS (US-056F DUAL DTO ARCHITECTURE)
    // ========================================
    
    /**
     * Find step master by ID and return as StepMasterDTO
     * @param stepMasterId Step master ID (UUID)
     * @return StepMasterDTO or null if not found
     */
    StepMasterDTO findMasterByIdAsDTO(UUID stepMasterId) {
        DatabaseUtil.withSql { sql ->
            def row = sql.firstRow('''
                SELECT stm.stm_id,
                       stm.stt_code,
                       stm.stm_number,
                       stm.stm_name,
                       stm.stm_description,
                       stm.phm_id,
                       stm.created_date,
                       stm.last_modified_date,
                       (SELECT COUNT(*) FROM instructions_master_inm
                        WHERE inm.stm_id = stm.stm_id) as instruction_count,
                       (SELECT COUNT(*) FROM steps_instance_sti
                        WHERE sti.stm_id = stm.stm_id) as instance_count
                FROM steps_master_stm stm
                WHERE stm.stm_id = :stepMasterId
            ''', [stepMasterId: stepMasterId])
            
            return row ? transformationService.fromMasterDatabaseRow(row) : null
        }
    }
    
    /**
     * Find all step masters and return as StepMasterDTOs
     * @return List of StepMasterDTOs
     */
    def findAllMastersAsDTO() {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows('''
                SELECT stm.stm_id,
                       stm.stt_code,
                       stm.stm_number,
                       stm.stm_name,
                       stm.stm_description,
                       stm.phm_id,
                       stm.created_date,
                       stm.last_modified_date,
                       (SELECT COUNT(*) FROM instructions_master_inm
                        WHERE inm.stm_id = stm.stm_id) as instruction_count,
                       (SELECT COUNT(*) FROM steps_instance_sti
                        WHERE sti.stm_id = stm.stm_id) as instance_count
                FROM steps_master_stm stm
                ORDER BY stm.stt_code, stm.stm_number
            ''')
            
            return transformationService.fromMasterDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find step masters by phase ID and return as StepMasterDTOs
     * @param phaseId Phase master ID (UUID)
     * @return List of StepMasterDTOs for the phase
     */
    def findMastersByPhaseIdAsDTO(UUID phaseId) {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows('''
                SELECT stm.stm_id,
                       stm.stt_code,
                       stm.stm_number,
                       stm.stm_name,
                       stm.stm_description,
                       stm.phm_id,
                       stm.created_date,
                       stm.last_modified_date,
                       (SELECT COUNT(*) FROM instructions_master_inm
                        WHERE inm.stm_id = stm.stm_id) as instruction_count,
                       (SELECT COUNT(*) FROM steps_instance_sti
                        WHERE sti.stm_id = stm.stm_id) as instance_count
                FROM steps_master_stm stm
                WHERE stm.phm_id = :phaseId
                ORDER BY stm.stm_number
            ''', [phaseId: phaseId])
            
            return transformationService.fromMasterDatabaseRows(rows as List<Map>)
        }
    }
    
    // ========================================
    // INSTANCE DTO METHODS (RENAMED FOR CLARITY)
    // ========================================
    
    /**
     * Find step by ID and return as StepInstanceDTO (renamed from findByIdAsDTO)
     * @param stepId Step master or instance ID
     * @return StepInstanceDTO or null if not found
     */
    def findByIdAsDTO(UUID stepId) {
        DatabaseUtil.withSql { sql ->
            def row = sql.firstRow(buildDTOBaseQuery() + '''
                WHERE (stm.stm_id = :stepId OR sti.sti_id = :stepId)
            ''', [stepId: stepId])
            
            return row ? transformationService.fromDatabaseRow(row) : null
        }
    }
    
    /**
     * Find step by instance ID and return as StepInstanceDTO  
     * @param stepInstanceId Step instance ID
     * @return StepInstanceDTO or null if not found
     */
    def findByInstanceIdAsDTO(UUID stepInstanceId) {
        DatabaseUtil.withSql { sql ->
            def row = sql.firstRow(buildDTOBaseQuery() + '''
                WHERE sti.sti_id = :stepInstanceId
                
            ''', [stepInstanceId: stepInstanceId])
            
            return row ? transformationService.fromDatabaseRow(row) : null
        }
    }
    
    /**
     * Find all steps in a phase and return as StepInstanceDTO list
     * @param phaseId Phase ID (use instance ID for proper hierarchical filtering)
     * @return List of StepInstanceDTOs
     */
    def findByPhaseIdAsDTO(UUID phaseId) {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows(buildDTOBaseQuery() + '''
                WHERE (phi.phi_id = :phaseId OR stm.phm_id = :phaseId)
                
                ORDER BY stm.stm_number, sti.created_at
            ''', [phaseId: phaseId])
            
            return transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find all steps in a migration and return as StepInstanceDTO list
     * @param migrationId Migration ID  
     * @return List of StepInstanceDTOs
     */
    def findByMigrationIdAsDTO(UUID migrationId) {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows(buildDTOBaseQuery() + '''
                WHERE mig.mig_id = :migrationId

                ORDER BY sqm.sqm_order, phm.phm_order, stm.stm_number, sti.created_at
            ''', [migrationId: migrationId])
            
            return transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find all steps in an iteration and return as StepInstanceDTO list
     * @param iterationId Iteration ID
     * @return List of StepInstanceDTOs  
     */
    def findByIterationIdAsDTO(UUID iterationId) {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows(buildDTOBaseQuery() + '''
                WHERE ite.ite_id = :iterationId

                ORDER BY sqm.sqm_order, phm.phm_order, stm.stm_number, sti.created_at
            ''', [iterationId: iterationId])
            
            return transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find steps by status and return as StepInstanceDTO list
     * @param status Step status (PENDING, IN_PROGRESS, COMPLETED, FAILED, CANCELLED)
     * @param limit Maximum number of results (default: 100)
     * @return List of StepInstanceDTOs
     */
    def findByStatusAsDTO(String status, int limit = 100) {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows(buildDTOBaseQuery() + '''
                WHERE sti.sti_status = :status
                
                ORDER BY sti.updated_at DESC
                LIMIT :limit
            ''', [status: status, limit: limit])
            
            return transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find steps assigned to a team and return as StepInstanceDTO list
     * @param teamId Team ID
     * @return List of StepInstanceDTOs
     */
    def findByAssignedTeamIdAsDTO(UUID teamId) {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows(buildDTOBaseQuery() + '''
                WHERE tms.tms_id = :teamId
                
                ORDER BY sti.sti_status, sti.created_at
            ''', [teamId: teamId])
            
            return transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find steps with active comments and return as StepInstanceDTO list
     * @param limit Maximum number of results (default: 50)  
     * @return List of StepInstanceDTOs
     */
    def findStepsWithActiveCommentsAsDTO(int limit = 50) {
        DatabaseUtil.withSql { sql ->
            def rows = sql.rows(buildDTOBaseQuery() + '''
                WHERE comment_count > 0
                
                ORDER BY last_comment_date DESC
                LIMIT :limit
            ''', [limit: limit])
            
            return transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find filtered step instances and return as StepInstanceDTOs (hierarchical filtering)
     * This is the DTO version of findFilteredStepInstances for the main GET /steps endpoint
     * @param filters Map of filter parameters (migrationId, iterationId, planId, sequenceId, phaseId, teamId, labelId)
     * @return List of StepInstanceDTOs with hierarchical ordering
     */
    def findFilteredStepInstancesAsDTO(Map filters) {
        DatabaseUtil.withSql { sql ->
            def query = buildDTOBaseQuery()
            def params = [:]
            def whereConditions = []
            
            // Add hierarchical filters
            if (filters.migrationId) {
                whereConditions << "mig.mig_id = :migrationId"
                params.migrationId = UUID.fromString(filters.migrationId as String)
            }
            
            if (filters.iterationId) {
                whereConditions << "ite.ite_id = :iterationId"
                params.iterationId = UUID.fromString(filters.iterationId as String)
            }
            
            if (filters.planId) {
                whereConditions << "pli.pli_id = :planId"
                params.planId = UUID.fromString(filters.planId as String)
            }
            
            if (filters.sequenceId) {
                whereConditions << "sqi.sqi_id = :sequenceId"
                params.sequenceId = UUID.fromString(filters.sequenceId as String)
            }
            
            if (filters.phaseId) {
                whereConditions << "phi.phi_id = :phaseId"
                params.phaseId = UUID.fromString(filters.phaseId as String)
            }
            
            // Add team filter
            if (filters.teamId) {
                whereConditions << "stm.tms_id_owner = :teamId"
                params.teamId = Integer.parseInt(filters.teamId as String)
            }
            
            // Add label filter (through step-label join table)
            if (filters.labelId) {
                whereConditions << '''EXISTS (
                        SELECT 1 FROM labels_lbl_x_steps_master_stm lxs 
                        WHERE lxs.stm_id = stm.stm_id AND lxs.lbl_id = :labelId
                    )'''
                params.labelId = Integer.parseInt(filters.labelId as String)
            }
            
            def whereClause = whereConditions ? "WHERE ${whereConditions.join(' AND ')}" : ""
            def orderByClause = "ORDER BY sqm.sqm_order, phm.phm_order, stm.stm_number"
            
            def finalQuery = query + " " + whereClause + " " + orderByClause
            def rows = sql.rows(finalQuery, params)
            
            return transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
        }
    }
    
    /**
     * Find master steps with filters and return as StepMasterDTOs
     * This is the DTO version of findMasterStepsWithFilters for the GET /steps/master endpoint
     * @param filters Map of filter parameters
     * @param pageNumber Page number (1-based)
     * @param pageSize Number of items per page
     * @param sortField Field to sort by
     * @param sortDirection Sort direction (asc/desc)
     * @return Map with StepMasterDTOs, pagination info, and filters
     */
    def findMasterStepsWithFiltersAsDTO(Map filters, int pageNumber = 1, int pageSize = 50, String sortField = null, String sortDirection = 'asc') {
        DatabaseUtil.withSql { sql ->
            pageNumber = Math.max(1, pageNumber)
            pageSize = Math.min(100, Math.max(1, pageSize))
            
            def whereConditions = []
            def params = [:]
            
            // Build WHERE clause from filters
            if (filters.stm_id) {
                whereConditions << "stm.stm_id = :stmId"
                params.stmId = UUID.fromString(filters.stm_id as String)
            }
            
            if (filters.stm_name) {
                whereConditions << "LOWER(stm.stm_name) LIKE LOWER(:stmName)"
                params.stmName = "%${filters.stm_name}%"
            }
            
            if (filters.stt_code) {
                whereConditions << "stm.stt_code = :sttCode"
                params.sttCode = filters.stt_code
            }
            
            def whereClause = whereConditions ? "WHERE ${whereConditions.join(' AND ')}" : ""
            
            // Validate and set sort field
            def allowedSortFields = ['stm_id', 'stm_name', 'stm_number', 'created_at', 'updated_at', 'instruction_count', 'instance_count', 'plm_name', 'sqm_name', 'phm_name']
            def actualSortField = allowedSortFields.contains(sortField) ? sortField : 'stm.stm_number'
            def actualSortDirection = (sortDirection?.toLowerCase() == 'desc') ? 'DESC' : 'ASC'
            
            // Count query for pagination
            def countQuery = """
                SELECT COUNT(DISTINCT stm.stm_id)
                FROM steps_master_stm stm
                JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
                JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id
                JOIN plans_master_plm plm ON sqm.plm_id = plm.plm_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                ${whereClause}
            """
            
            def totalCount = sql.firstRow(countQuery, params)[0] as Integer
            def totalPages = Math.ceil(totalCount / (double) pageSize) as Integer
            
            // Main query with pagination
            def offset = (pageNumber - 1) * pageSize
            params.limit = pageSize
            params.offset = offset
            
            def dataQuery = """
                SELECT stm.stm_id,
                       stm.stt_code,
                       stm.stm_number,
                       stm.stm_name,
                       stm.stm_description,
                       stm.phm_id,
                       stm.created_date,
                       stm.last_modified_date,
                       phm.phm_name,
                       sqm.sqm_name,
                       plm.plm_name,
                       tms.tms_name as owner_team_name,
                       (SELECT COUNT(*) FROM instructions_master_inm inm
                        WHERE inm.stm_id = stm.stm_id) as instruction_count,
                       (SELECT COUNT(*) FROM steps_instance_sti sti
                        WHERE sti.stm_id = stm.stm_id) as instance_count
                FROM steps_master_stm stm
                JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
                JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id
                JOIN plans_master_plm plm ON sqm.plm_id = plm.plm_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                ${whereClause}
                ORDER BY ${actualSortField} ${actualSortDirection}
                LIMIT :limit OFFSET :offset
            """
            
            def rows = sql.rows(dataQuery, params)
            def dtos = transformationService.fromMasterDatabaseRows(rows as List<Map>)
            
            return [
                data: dtos,
                pagination: [
                    pageNumber: pageNumber,
                    pageSize: pageSize,
                    totalPages: totalPages,
                    totalCount: totalCount,
                    hasNext: pageNumber < totalPages,
                    hasPrevious: pageNumber > 1
                ],
                filters: filters,
                sort: [
                    field: actualSortField,
                    direction: actualSortDirection
                ]
            ]
        }
    }
    
    /**
     * Create a new step from StepInstanceDTO
     * Supports both step master and step instance creation
     * 
     * @param stepDTO Step data transfer object to create
     * @return Created StepInstanceDTO with generated IDs
     * @throws IllegalArgumentException If required fields are missing
     * @throws SQLException If database constraint violations occur
     */
    def createDTO(StepInstanceDTO stepDTO) {
        if (!stepDTO) {
            throw new IllegalArgumentException("StepInstanceDTO cannot be null")
        }
        
        DatabaseUtil.withSql { sql ->
            try {
                UUID newInstanceId
                sql.withTransaction { txnSql ->
                    UUID newStepId
                    
                    // For DTO-based operations, we work with step instances directly
                    // Master step creation is handled separately if needed
                    if (!stepDTO.stepId) {
                        if (!stepDTO.stepType || !stepDTO.stepName) {
                            throw new IllegalArgumentException("Step creation requires stepType and stepName")
                        }
                        
                        newStepId = UUID.randomUUID()
                        stepDTO.stepId = newStepId.toString()
                        
                        // Note: Master step creation would be handled by a separate service
                        // For now, we'll create the instance with a generated master ID
                        def masterParams = [
                            stm_id: newStepId,
                            stt_code: stepDTO.stepType,
                            stm_number: 1, // Default step number for DTO operations
                            stm_name: stepDTO.stepName,
                            stm_description: stepDTO.stepDescription,
                            phm_id: stepDTO.phaseId ? UUID.fromString(stepDTO.phaseId) : null,
                            stm_duration_minutes: stepDTO.estimatedDuration,
                            tms_id_owner: 1, // Default team owner - required field
                            enr_id_target: 1 // Default environment role target - required field
                        ]
                        
                        def insertMasterSql = '''
                            INSERT INTO steps_master_stm (
                                stm_id, stt_code, stm_number, stm_name, stm_description, phm_id,
                                stm_duration_minutes, tms_id_owner, enr_id_target
                            ) VALUES (
                                :stm_id, :stt_code, :stm_number, :stm_name, :stm_description, :phm_id,
                                :stm_duration_minutes, :tms_id_owner, :enr_id_target
                            )
                        '''
                        
                        sql.executeUpdate(insertMasterSql, masterParams)
                        // stepId is already set above for DTO consistency
                    } else {
                        newStepId = UUID.fromString(stepDTO.stepId)
                    }
                    
                    // Create step instance if required data is present
                    newInstanceId = UUID.randomUUID()
                    
                    def instanceParams = [
                        sti_id: newInstanceId,
                        stm_id: newStepId,
                        phi_id: stepDTO.phaseId ? UUID.fromString(stepDTO.phaseId) : null,
                        sti_name: stepDTO.stepName,
                        sti_description: stepDTO.stepDescription,
                        sti_status: stepDTO.stepStatus ?: 'PENDING',
                        // sti_priority: stepDTO.priority ?: 5, // Column doesn't exist
                        sti_start_time: stepDTO.createdDate ? Timestamp.valueOf(stepDTO.createdDate) : null,
                        sti_end_time: stepDTO.lastModifiedDate ? Timestamp.valueOf(stepDTO.lastModifiedDate) : null,
                        created_at: new Timestamp(System.currentTimeMillis()),
                        updated_at: new Timestamp(System.currentTimeMillis())
                    ]

                    def insertInstanceSql = '''
                        INSERT INTO steps_instance_sti (
                            sti_id, stm_id, phi_id, sti_name, sti_description,
                            sti_status, sti_start_time, sti_end_time,
                            created_at, updated_at
                        ) VALUES (
                            :sti_id, :stm_id, :phi_id, :sti_name, :sti_description,
                            :sti_status, :sti_start_time, :sti_end_time,
                            :created_at, :updated_at
                        )
                    '''
                    
                    sql.executeUpdate(insertInstanceSql, instanceParams)
                    stepDTO.stepInstanceId = newInstanceId
                    
                    // Handle impacted teams relationships
                    // Note: StepInstanceDTO currently doesn't support impacted teams collection
                    // This would need to be handled by a separate service method if required
                    // For now, we'll use the assignedTeamId as a default relationship
                    if (stepDTO.assignedTeamId) {
                        def teamParams = [stm_id: newStepId, tms_id: UUID.fromString(stepDTO.assignedTeamId)]
                        def insertTeamSql = '''
                            INSERT INTO steps_master_stm_x_teams_tms_impacted (stm_id, tms_id)
                            VALUES (:stm_id, :tms_id)
                        '''
                        sql.executeUpdate(insertTeamSql, teamParams)
                    }
                    
                    // Handle iteration types relationships
                    // Note: StepInstanceDTO currently doesn't support iteration types collection
                    // This would need to be handled by a separate service method if required
                    // For now, we'll skip this relationship as it's not available in the DTO
                    // If needed, this could be added to the DTO in a future enhancement
                }
                
                // Return the created DTO with populated IDs
                // Use the step instance ID we just created
                stepDTO.stepInstanceId = newInstanceId.toString()
                return findByIdAsDTO(newInstanceId)
                
            } catch (SQLException e) {
                // Map SQL states to appropriate HTTP codes following ADR pattern
                if (e.getSQLState() == '23503') { // Foreign key constraint
                    throw new IllegalArgumentException("Referenced entity not found: ${e.message}", e)
                } else if (e.getSQLState() == '23505') { // Unique constraint
                    throw new IllegalStateException("Step already exists: ${e.message}", e)
                }
                throw e
            }
        }
    }
    
    /**
     * Update an existing step from StepInstanceDTO
     * Supports both step master and step instance updates with optimistic locking
     * 
     * @param stepDTO Step data transfer object to update
     * @return Updated StepInstanceDTO
     * @throws IllegalArgumentException If stepDTO is invalid or required IDs are missing
     * @throws IllegalStateException If optimistic locking fails or record not found
     * @throws SQLException If database constraint violations occur
     */
    def updateDTO(StepInstanceDTO stepDTO) {
        if (!stepDTO) {
            throw new IllegalArgumentException("StepInstanceDTO cannot be null")
        }
        if (!stepDTO.stepInstanceId && !stepDTO.stepId) {
            throw new IllegalArgumentException("Either stepInstanceId or stepId must be provided for updates")
        }
        
        return DatabaseUtil.withSql { sql ->
            try {
                sql.withTransaction { txnSql ->
                    def now = new Timestamp(System.currentTimeMillis())
                    def updated = false
                    
                    // Update step master if stepId is provided and data has changed
                    if (stepDTO.stepId) {
                        def masterParams = [
                            stm_id: UUID.fromString(stepDTO.stepId),
                            stt_code: stepDTO.stepType,
                            stm_number: 1, // Default for DTO operations
                            stm_name: stepDTO.stepName,
                            stm_description: stepDTO.stepDescription,
                            phm_id: stepDTO.phaseId ? UUID.fromString(stepDTO.phaseId) : null,
                            stm_duration_minutes: stepDTO.estimatedDuration
                        ]
                        
                        def updateMasterSql = '''
                            UPDATE steps_master_stm SET
                                stt_code = :stt_code,
                                stm_number = :stm_number,
                                stm_name = :stm_name,
                                stm_description = :stm_description,
                                phm_id = :phm_id,
                                stm_duration_minutes = :stm_duration_minutes
                            WHERE stm_id = :stm_id
                        '''
                        
                        def masterUpdateCount = sql.executeUpdate(updateMasterSql, masterParams)
                        if (masterUpdateCount == 0) {
                            throw new IllegalStateException("Step master not found or no changes applied: ${stepDTO.stepId}")
                        }
                        updated = true
                        
                        // Update impacted teams relationships
                        // First, remove existing relationships
                        sql.executeUpdate('''
                            DELETE FROM steps_master_stm_x_teams_tms_impacted 
                            WHERE stm_id = :stm_id
                        ''', [stm_id: UUID.fromString(stepDTO.stepId)])
                        
                        // Add new relationships - using assignedTeamId as default
                        if (stepDTO.assignedTeamId) {
                            def teamParams = [stm_id: UUID.fromString(stepDTO.stepId), tms_id: UUID.fromString(stepDTO.assignedTeamId)]
                            def insertTeamSql = '''
                                INSERT INTO steps_master_stm_x_teams_tms_impacted (stm_id, tms_id)
                                VALUES (:stm_id, :tms_id)
                            '''
                            sql.executeUpdate(insertTeamSql, teamParams)
                        }
                        
                        // Update iteration types relationships
                        // First, remove existing relationships
                        sql.executeUpdate('''
                            DELETE FROM steps_master_stm_x_iteration_types_itt 
                            WHERE stm_id = :stm_id
                        ''', [stm_id: UUID.fromString(stepDTO.stepId)])
                        
                        // Skip iteration types relationships - not supported in current DTO
                        // This would need to be handled by a separate service method if required
                    }
                    
                    // Update step instance if stepInstanceId is provided
                    if (stepDTO.stepInstanceId) {
                        def instanceParams = [
                            sti_id: UUID.fromString(stepDTO.stepInstanceId),
                            phi_id: stepDTO.phaseId ? UUID.fromString(stepDTO.phaseId) : null,
                            sti_name: stepDTO.stepName,
                            sti_description: stepDTO.stepDescription,
                            sti_status: stepDTO.stepStatus,
                            // sti_priority: stepDTO.priority, // Column doesn't exist
                            sti_planned_start_date: stepDTO.createdDate ? Timestamp.valueOf(stepDTO.createdDate) : null,
                            sti_planned_end_date: stepDTO.lastModifiedDate ? Timestamp.valueOf(stepDTO.lastModifiedDate) : null,
                            sti_actual_start_date: null, // Not available in current DTO
                            sti_actual_end_date: null, // Not available in current DTO
                            updated_at: now
                        ]
                        
                        def updateInstanceSql = '''
                            UPDATE steps_instance_sti SET
                                phi_id = :phi_id,
                                sti_name = :sti_name,
                                sti_description = :sti_description,
                                sti_status = :sti_status,
                                sti_planned_start_date = :sti_planned_start_date,
                                sti_planned_end_date = :sti_planned_end_date,
                                sti_actual_start_date = :sti_actual_start_date,
                                sti_actual_end_date = :sti_actual_end_date,
                                updated_at = :updated_at
                            WHERE sti_id = :sti_id
                        '''
                        
                        def instanceUpdateCount = sql.executeUpdate(updateInstanceSql, instanceParams)
                        if (instanceUpdateCount == 0) {
                            throw new IllegalStateException("Step instance not found or no changes applied: ${stepDTO.stepInstanceId}")
                        }
                        updated = true
                    }
                    
                    if (!updated) {
                        throw new IllegalStateException("No updates performed - invalid or unchanged data")
                    }
                }
                
                // Return the updated DTO
                def targetId = stepDTO.stepInstanceId ?: stepDTO.stepId
                return findByIdAsDTO(UUID.fromString(targetId as String))
            } catch (SQLException e) {
                // Map SQL states to appropriate HTTP codes following ADR pattern
                if (e.getSQLState() == '23503') { // Foreign key constraint
                    throw new IllegalArgumentException("Referenced entity not found: ${e.message}", e)
                } else if (e.getSQLState() == '23505') { // Unique constraint
                    throw new IllegalStateException("Duplicate entry: ${e.message}", e)
                }
                throw e
            }
        }
    }
    
    /**
     * Save (create or update) a step from StepInstanceDTO
     * Determines whether to create or update based on presence of IDs
     * 
     * @param stepDTO Step data transfer object to save
     * @return Saved StepInstanceDTO
     */
    def saveDTO(StepInstanceDTO stepDTO) {
        if (!stepDTO) {
            throw new IllegalArgumentException("StepInstanceDTO cannot be null")
        }
        
        // Determine if this is a create or update operation
        if (stepDTO.stepInstanceId || stepDTO.stepId) {
            // If IDs are present, verify the entity exists
            def targetId = stepDTO.stepInstanceId ?: stepDTO.stepId
            def existing = findByIdAsDTO(UUID.fromString(targetId as String))
            if (existing) {
                return updateDTO(stepDTO)
            }
        }
        
        // If no existing entity found or no IDs provided, create new
        return createDTO(stepDTO)
    }
    
    /**
     * Batch save multiple steps from StepInstanceDTO list
     * Optimized for performance with transaction management
     * 
     * @param stepDTOs List of Step data transfer objects to save
     * @return List of saved StepInstanceDTOs
     */
    def batchSaveDTO(List<StepInstanceDTO> stepDTOs) {
        if (!stepDTOs) {
            return []
        }
        
        def results = []
        DatabaseUtil.withSql { sql ->
            sql.withTransaction { txnSql ->
                stepDTOs.each { stepDTO ->
                    results.add(saveDTO(stepDTO))
                }
            }
        }
        
        return results
    }
    
    /**
     * Build the comprehensive base query for DTO population
     * This query includes all fields needed for StepInstanceDTO construction
     * REFACTORED: Consolidated method with comprehensive labels logging
     * @return SQL query string
     */
    private String buildDTOBaseQuery() {
        log.info("*** LABELS REFACTOR *** buildDTOBaseQuery() called - CONSOLIDATED VERSION")
        return buildComprehensiveDTOQuery()
    }

    /**
     * REFACTORED: Consolidated comprehensive base query with enhanced labels debugging
     * This is the single source of truth for all DTO queries with labels
     * @return SQL query string with comprehensive labels integration
     */
    private String buildComprehensiveDTOQuery() {
        log.info("*** LABELS REFACTOR *** buildComprehensiveDTOQuery() executing - comprehensive labels integration")
        return '''
            SELECT
                -- Core step identification
                stm.stm_id,
                sti.sti_id,
                stm.stm_name as step_master_name,
                stm.stm_description,
                COALESCE(sti.sti_name, stm.stm_name) as display_name,
                COALESCE(sti.sti_description, stm.stm_description) as display_description,
                sts.sts_name as step_status,

                -- Team assignment
                tms.tms_id,
                tms.tms_name as team_name,

                -- Hierarchical context
                mig.mig_id as migration_id,
                mig.mig_name as migration_name,
                ite.ite_id as iteration_id,
                itt.itt_code as iteration_type,
                sqm.sqm_id as sequence_id,
                sqm.sqm_name as sequence_name,
                sqm.sqm_order,  -- Added for hierarchical sorting
                phm.phm_id as phase_id,
                phm.phm_name as phase_name,
                phm.phm_order,  -- Added for hierarchical sorting
                stm.stm_number, -- Added for hierarchical sorting

                -- Instance hierarchy order fields (required by transformation service)
                COALESCE(sqi.sqi_order, sqm.sqm_order) as sqi_order,
                COALESCE(phi.phi_order, phm.phm_order) as phi_order,

                -- Temporal fields
                sti.created_at as created_date,
                sti.updated_at as last_modified_date,
                true as is_active,  -- Default to true since column doesn't exist
                -- priority column doesn't exist in database

                -- Extended metadata
                stt.stt_code,
                stt.stt_name,
                stm.stm_duration_minutes,
                sti.sti_duration_minutes,

                -- Environment role information (from steps_instance_sti → environment_roles_enr)
                enr.enr_id as environment_id,
                enr.enr_name as environment_name,

                -- Predecessor information (from steps_master_stm.stm_id_predecessor)
                predecessor_stm.stm_id as predecessor_id,
                predecessor_stt.stt_code as predecessor_type,
                predecessor_stm.stm_number as predecessor_number,
                CONCAT(predecessor_stt.stt_code, '-', predecessor_stm.stm_number) as predecessor_code,
                predecessor_stm.stm_name as predecessor_name,

                -- Impacted teams (aggregated from steps_master_stm_x_teams_tms_impacted)
                COALESCE(impacted_teams.impacted_teams_list, '') as impacted_teams,

                -- Progress tracking with computed values
                COALESCE(dep_counts.dependency_count, 0) as dependency_count,
                COALESCE(dep_counts.completed_dependencies, 0) as completed_dependencies,
                COALESCE(inst_counts.instruction_count, 0) as instruction_count,
                COALESCE(inst_counts.completed_instructions, 0) as completed_instructions,

                -- Comment integration
                COALESCE(comment_counts.comment_count, 0) as comment_count,
                CASE WHEN comment_counts.comment_count > 0 THEN true ELSE false END as has_active_comments,
                comment_counts.last_comment_date,

                -- REFACTORED LABELS: Enhanced debugging and error handling
                COALESCE(step_labels.labels, '[]'::json) as labels,
                step_labels.label_count_debug

            FROM steps_instance_sti sti
            JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
            JOIN step_types_stt stt ON stm.stt_code = stt.stt_code
            JOIN status_sts sts ON sti.sti_status = sts.sts_id AND sts.sts_type = 'Step'

            -- Hierarchical joins
            JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
            JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id

            -- Instance hierarchy for proper filtering
            JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
            JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
            JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id

            -- Migration and iteration context
            JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
            LEFT JOIN iteration_types_itt itt ON ite.itt_code = itt.itt_code
            LEFT JOIN migrations_mig mig ON ite.mig_id = mig.mig_id

            -- Team assignment (using step master's owner team)
            LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id

            -- Environment role assignment (from step instance)
            LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id

            -- Predecessor relationship (from step master)
            LEFT JOIN steps_master_stm predecessor_stm ON stm.stm_id_predecessor = predecessor_stm.stm_id
            LEFT JOIN step_types_stt predecessor_stt ON predecessor_stm.stt_code = predecessor_stt.stt_code

            -- Impacted teams aggregation
            LEFT JOIN (
                SELECT
                    stm_id,
                    STRING_AGG(tms.tms_name, ', ' ORDER BY tms.tms_name) as impacted_teams_list
                FROM steps_master_stm_x_teams_tms_impacted stm_x_tms
                JOIN teams_tms tms ON stm_x_tms.tms_id = tms.tms_id
                GROUP BY stm_id
            ) impacted_teams ON stm.stm_id = impacted_teams.stm_id

            -- Dependency counts subquery (based on predecessor relationships in steps_master_stm)
            LEFT JOIN (
                SELECT
                    dependent_step.stm_id as dependent_stm_id,
                    COUNT(*) as dependency_count,
                    SUM(CASE WHEN predecessor_status.sts_name = '${getCompletedStepStatus()}' THEN 1 ELSE 0 END) as completed_dependencies
                FROM steps_master_stm dependent_step
                JOIN steps_master_stm predecessor_step ON dependent_step.stm_id_predecessor = predecessor_step.stm_id
                LEFT JOIN steps_instance_sti predecessor_instances ON predecessor_step.stm_id = predecessor_instances.stm_id
                LEFT JOIN status_sts predecessor_status ON predecessor_instances.sti_status = predecessor_status.sts_id
                GROUP BY dependent_step.stm_id
            ) dep_counts ON stm.stm_id = dep_counts.dependent_stm_id

            -- Instruction counts subquery (corrected column names)
            LEFT JOIN (
                SELECT
                    sti_id,
                    COUNT(*) as instruction_count,
                    SUM(CASE WHEN ini_is_completed = true THEN 1 ELSE 0 END) as completed_instructions
                FROM instructions_instance_ini
                GROUP BY sti_id
            ) inst_counts ON sti.sti_id = inst_counts.sti_id

            -- Comment counts and latest comment date (removed non-existent is_active field)
            LEFT JOIN (
                SELECT
                    sti_id,
                    COUNT(*) as comment_count,
                    MAX(created_at) as last_comment_date
                FROM step_instance_comments_sic
                GROUP BY sti_id
            ) comment_counts ON sti.sti_id = comment_counts.sti_id

            -- REFACTORED LABELS: Enhanced subquery with debugging and comprehensive error handling
            -- REFACTOR DATE: 2025-09-21 - Comprehensive labels integration refactor
            LEFT JOIN (
                SELECT
                    lxs.stm_id,
                    json_agg(
                        json_build_object(
                            'id', lbl.lbl_id,
                            'name', lbl.lbl_name,
                            'color', lbl.lbl_color,
                            'description', lbl.lbl_description
                        ) ORDER BY lbl.lbl_name
                    ) FILTER (WHERE lbl.lbl_id IS NOT NULL) as labels,
                    COUNT(lbl.lbl_id) as label_count_debug
                FROM labels_lbl_x_steps_master_stm lxs
                INNER JOIN labels_lbl lbl ON lxs.lbl_id = lbl.lbl_id
                WHERE lbl.lbl_id IS NOT NULL
                GROUP BY lxs.stm_id
            ) step_labels ON stm.stm_id = step_labels.stm_id
        '''
    }

    /**
     * DEPRECATED: Use buildComprehensiveDTOQuery() instead
     * Maintained for backward compatibility during refactor period
     */
    private String buildDTOBaseQuery_v2() {
        log.warn("*** LABELS REFACTOR WARNING *** buildDTOBaseQuery_v2() is deprecated - redirecting to consolidated method")
        return buildComprehensiveDTOQuery()
    }

    /**
     * REFACTOR TEST METHOD: Test labels SQL independently to verify data exists
     * This method directly tests the labels JOIN to verify data integrity
     * @return Map with debug information about labels
     */
    def testLabelsDataIntegrity() {
        DatabaseUtil.withSql { sql ->
            log.info("*** LABELS REFACTOR TEST *** Testing labels data integrity")

            // Test 1: Check if any step-label relationships exist
            def labelRelationshipCount = sql.firstRow("""
                SELECT COUNT(*) as count
                FROM labels_lbl_x_steps_master_stm lxs
                INNER JOIN labels_lbl lbl ON lxs.lbl_id = lbl.lbl_id
                INNER JOIN steps_master_stm stm ON lxs.stm_id = stm.stm_id
            """)[0] as Integer

            log.info("*** LABELS REFACTOR TEST *** Found ${labelRelationshipCount} step-label relationships")

            // Test 2: Get sample step with labels using the exact SQL from our query
            def testRows = sql.rows("""
                SELECT
                    stm.stm_id,
                    stm.stm_name,
                    COALESCE(step_labels.labels, '[]'::json) as labels,
                    step_labels.label_count_debug
                FROM steps_master_stm stm
                LEFT JOIN (
                    SELECT
                        lxs.stm_id,
                        json_agg(
                            json_build_object(
                                'id', lbl.lbl_id,
                                'name', lbl.lbl_name,
                                'color', lbl.lbl_color,
                                'description', lbl.lbl_description
                            ) ORDER BY lbl.lbl_name
                        ) FILTER (WHERE lbl.lbl_id IS NOT NULL) as labels,
                        COUNT(lbl.lbl_id) as label_count_debug
                    FROM labels_lbl_x_steps_master_stm lxs
                    INNER JOIN labels_lbl lbl ON lxs.lbl_id = lbl.lbl_id
                    WHERE lbl.lbl_id IS NOT NULL
                    GROUP BY lxs.stm_id
                ) step_labels ON stm.stm_id = step_labels.stm_id
                LIMIT 10
            """)

            log.info("*** LABELS REFACTOR TEST *** Sample query returned ${testRows.size()} rows")

            def rowsWithLabels = testRows.findAll { it.labels && it.labels.toString() != '[]' && it.labels.toString() != 'null' }
            log.info("*** LABELS REFACTOR TEST *** ${rowsWithLabels.size()} rows have labels")

            testRows.eachWithIndex { row, index ->
                log.info("*** LABELS REFACTOR TEST *** Row ${index}: ${row.stm_name} - Labels: '${row.labels}' (type: ${row.labels?.getClass()?.simpleName}), Debug count: ${row.label_count_debug}")
            }

            return [
                totalRelationships: labelRelationshipCount,
                testRowsCount: testRows.size(),
                rowsWithLabels: rowsWithLabels.size(),
                sampleRows: testRows.collect { [name: it.stm_name, labels: it.labels, debugCount: it.label_count_debug] }
            ]
        }
    }
    
    /**
     * Find steps with filters and return as StepInstanceDTO list with pagination
     * Enhanced version of existing findMasterStepsWithFilters that returns DTOs
     * Updated: Fixed labels field names for frontend compatibility (name, color, description)
     * @param filters Map of filter parameters  
     * @param pageNumber Page number (1-based)
     * @param pageSize Number of items per page
     * @param sortField Field to sort by
     * @param sortDirection Sort direction (asc/desc)
     * @return Map with DTO data, pagination info, and filters
     */
    def findStepsWithFiltersAsDTO_v2(Map filters, int pageNumber = 1, int pageSize = 50, String sortField = 'created_date', String sortDirection = 'desc') {
        DatabaseUtil.withSql { sql ->
            pageNumber = Math.max(1, pageNumber)
            pageSize = Math.min(100, Math.max(1, pageSize))

            // FORCE RELOAD: 2025-09-20 14:35 - Labels integration fix for iteration view
            log.info("*** LABELS DEBUG *** StepRepository.findStepsWithFiltersAsDTO called - Labels should be included via step_labels.labels field")
            // Log incoming filters for debugging
            log.info("StepRepository.findStepsWithFiltersAsDTO called with filters: ${filters}")
            log.info("Pagination: pageNumber=${pageNumber}, pageSize=${pageSize}, sortField=${sortField}, sortDirection=${sortDirection}")

            def whereConditions = []
            def params = [:]

            // Build dynamic WHERE clause
            if (filters.migrationId) {
                whereConditions << "mig.mig_id = :migrationId"
                params.migrationId = UUID.fromString(filters.migrationId as String)
                log.info("Added migration filter: mig.mig_id = ${params.migrationId}")
            }

            if (filters.iterationId) {
                whereConditions << "ite.ite_id = :iterationId"
                params.iterationId = UUID.fromString(filters.iterationId as String)
                log.info("Added iteration filter: ite.ite_id = ${params.iterationId}")
            }

            if (filters.planId) {
                whereConditions << "pli.pli_id = :planId"
                params.planId = UUID.fromString(filters.planId as String)
                log.info("Added plan filter: pli.pli_id = ${params.planId}")
            }

            if (filters.sequenceId) {
                whereConditions << "sqi.sqi_id = :sequenceId"
                params.sequenceId = UUID.fromString(filters.sequenceId as String)
                log.info("Added sequence filter: sqi.sqi_id = ${params.sequenceId}")
            }

            if (filters.phaseId) {
                whereConditions << "phi.phi_id = :phaseId"
                params.phaseId = UUID.fromString(filters.phaseId as String)
                log.info("Added phase filter: phi.phi_id = ${params.phaseId}")
            }

            if (filters.teamId) {
                whereConditions << "stm.tms_id_owner = :teamId"
                params.teamId = Integer.parseInt(filters.teamId as String)
                log.info("Added team filter: stm.tms_id_owner = ${params.teamId}")
            }

            // Add status filter
            if (filters.statusId) {
                whereConditions << "sti.sti_status = :statusId"
                params.statusId = Integer.parseInt(filters.statusId as String)
                log.info("Added status filter: sti.sti_status = ${params.statusId}")
            }

            // Add label filter (through step-label join table)
            if (filters.labelId) {
                whereConditions << '''EXISTS (
                    SELECT 1 FROM labels_lbl_x_steps_master_stm lxs
                    WHERE lxs.stm_id = stm.stm_id AND lxs.lbl_id = :labelId
                )'''
                params.labelId = Integer.parseInt(filters.labelId as String)
                log.info("Added label filter: lxs.lbl_id = ${params.labelId}")
            }

            if (filters.status) {
                whereConditions << "sti.sti_status = :status"
                params.status = filters.status as String
                log.info("Added status filter: sti.sti_status = ${params.status}")
            }

            if (filters.stepType) {
                whereConditions << "stt.stt_code = :stepType"
                params.stepType = filters.stepType as String
                log.info("Added step type filter: stt.stt_code = ${params.stepType}")
            }

            // Priority filtering disabled - column doesn't exist in database
            // if (filters.priority) {
            //     whereConditions << "sti.sti_priority = :priority"
            //     params.priority = Integer.parseInt(filters.priority as String)
            // }

            if (filters.hasActiveComments) {
                if (filters.hasActiveComments as Boolean) {
                    whereConditions << "comment_counts.comment_count > 0"
                    log.info("Added active comments filter: comment_count > 0")
                } else {
                    whereConditions << "(comment_counts.comment_count IS NULL OR comment_counts.comment_count = 0)"
                    log.info("Added no comments filter: comment_count IS NULL OR = 0")
                }
            }

            // No is_active filter - column doesn't exist in schema

            def whereClause = whereConditions ? "WHERE ${whereConditions.join(' AND ')}" : ""
            log.info("Generated WHERE clause: ${whereClause}")
            log.info("Query parameters: ${params}")
            
            // Build ORDER BY clause with safe field mapping
            def sortFieldMap = [
                'created_date': 'sti.created_at',
                'modified_date': 'sti.updated_at',
                'name': 'stm_name',
                'status': 'sts.sts_name',  // Fixed: Use status name from JOIN, not raw ID
                // 'priority': 'sti.sti_priority', // Column doesn't exist
                'team': 'tms.tms_name',
                // Frontend-to-backend field mappings (matching StepsApi field mapping)
                'sequence_number': 'sqi_order',    // Use instance order (COALESCE with master)
                'phase_number': 'phi_order',       // Use instance order (COALESCE with master)
                'step_number': 'stm.stm_number',
                // Hierarchical sorting fields (aliased from buildDTOBaseQuery)
                'sqi_order': 'sqi_order',
                'phi_order': 'phi_order',
                'stm.stm_number': 'stm.stm_number',
                'sti.created_at': 'sti.created_at',
                'sti.updated_at': 'sti.updated_at',
                'stm_name': 'stm_name',
                'step_status': 'sts.sts_name',
                'team_name': 'tms.tms_name'
            ]

            // Handle composite sort field (comma-separated)
            def actualSortDirection = (sortDirection?.toLowerCase() == 'asc') ? 'ASC' : 'DESC'
            def orderByClause

            if (sortField.contains(',')) {
                // Composite sort field - split and map each field
                def sortFields = sortField.split(',').collect { field ->
                    def mappedField = sortFieldMap[field.trim()] ?: field.trim()
                    return "${mappedField} ${actualSortDirection}"
                }
                def actualSortField = sortFields.join(', ')
                orderByClause = "ORDER BY ${actualSortField}"
            } else {
                // Single sort field
                def actualSortField = sortFieldMap[sortField] ?: 'sti.created_at'
                orderByClause = "ORDER BY ${actualSortField} ${actualSortDirection}"
            }
            
            // Execute count query for pagination
            def countQuery = """
                SELECT COUNT(DISTINCT sti.sti_id)
                FROM steps_instance_sti sti
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id
                JOIN step_types_stt stt ON stm.stt_code = stt.stt_code
                JOIN status_sts sts ON sti.sti_status = sts.sts_id AND sts.sts_type = 'Step'
                JOIN phases_master_phm phm ON stm.phm_id = phm.phm_id
                JOIN sequences_master_sqm sqm ON phm.sqm_id = sqm.sqm_id
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                LEFT JOIN migrations_mig mig ON ite.mig_id = mig.mig_id
                LEFT JOIN teams_tms tms ON stm.tms_id_owner = tms.tms_id
                LEFT JOIN (
                    SELECT sti_id, COUNT(*) as comment_count
                    FROM step_instance_comments_sic
                    GROUP BY sti_id
                ) comment_counts ON sti.sti_id = comment_counts.sti_id
                ${whereClause}
            """

            log.info("Executing COUNT query: ${countQuery}")
            log.info("COUNT query parameters: ${params}")

            def totalCount = sql.firstRow(countQuery, params)[0] as Integer
            log.info("COUNT query returned: ${totalCount} rows")
            def totalPages = Math.ceil(totalCount / (double) pageSize) as Integer
            
            // Execute main query with pagination
            def offset = (pageNumber - 1) * pageSize
            params.limit = pageSize
            params.offset = offset

            def dataQuery = buildComprehensiveDTOQuery() + """
                ${whereClause}
                ${orderByClause}
                LIMIT :limit OFFSET :offset
            """

            log.info("Executing MAIN query: ${dataQuery}")
            log.info("MAIN query parameters: ${params}")

            def rows = sql.rows(dataQuery, params)
            log.info("*** LABELS REFACTOR *** MAIN query returned: ${rows.size()} rows")

            // LABELS REFACTOR: Detailed inspection of raw database rows
            if (rows.size() > 0) {
                def firstRow = rows[0]
                log.info("*** LABELS REFACTOR *** First row labels field: '${firstRow.labels}' (type: ${firstRow.labels?.getClass()?.simpleName})")
                log.info("*** LABELS REFACTOR *** First row label_count_debug: ${firstRow.label_count_debug}")

                // Count how many rows have non-null labels
                def rowsWithLabels = rows.findAll { it.labels != null }
                def rowsWithNonEmptyLabels = rows.findAll { it.labels && it.labels.toString() != '[]' }
                log.info("*** LABELS REFACTOR *** ${rowsWithLabels.size()} rows have non-null labels, ${rowsWithNonEmptyLabels.size()} have non-empty labels")
            }

            def dtos = transformationService.batchTransformFromDatabaseRows(rows as List<Map>)
            log.info("*** LABELS REFACTOR *** Transformed to ${dtos.size()} DTOs")

            // LABELS REFACTOR: Detailed inspection of transformed DTOs
            def stepsWithLabels = dtos.findAll { it.labels && !it.labels.isEmpty() }
            log.info("*** LABELS REFACTOR *** ${stepsWithLabels.size()} out of ${dtos.size()} DTOs have labels after transformation")

            if (stepsWithLabels.size() > 0) {
                def firstStepWithLabels = stepsWithLabels[0]
                log.info("*** LABELS REFACTOR *** First DTO with labels: '${firstStepWithLabels.stepName}' has ${firstStepWithLabels.labels.size()} labels: ${firstStepWithLabels.labels}")
            } else if (dtos.size() > 0) {
                def firstDto = dtos[0]
                log.info("*** LABELS REFACTOR *** First DTO labels (empty): '${firstDto.stepName}' has labels: ${firstDto.labels}")
            }
            
            return [
                data: dtos,
                pagination: [
                    currentPage: pageNumber,
                    pageSize: pageSize,
                    totalCount: totalCount,
                    totalPages: totalPages,
                    hasNextPage: pageNumber < totalPages,
                    hasPreviousPage: pageNumber > 1
                ],
                filters: filters,
                sorting: [
                    field: sortField,
                    direction: sortDirection
                ]
            ]
        }
    }

    // ========================================
    // DTO WRITE OPERATIONS - US-056C Phase 2
    // ========================================

    /**
     * Create a new step master from DTO
     * Added for US-056C Phase 2 API integration
     * 
     * @param dto StepMasterDTO with data for new step
     * @return Created StepMasterDTO with generated ID
     */
    StepMasterDTO createMasterFromDTO(Map stepData) {
        log.debug("Creating new master step from DTO data")
        
        if (!stepData) {
            throw new IllegalArgumentException("Step data cannot be null")
        }
        
        return DatabaseUtil.withSql { sql ->
            try {
                // Generate new UUID for the step
                def stepId = UUID.randomUUID()
                
                // Validate required fields
                if (!stepData.phm_id || !stepData.tms_id_owner || !stepData.stt_code || 
                    !stepData.stm_number || !stepData.stm_name || !stepData.enr_id_target) {
                    throw new IllegalArgumentException("Missing required fields: phm_id, tms_id_owner, stt_code, stm_number, stm_name, enr_id_target are required")
                }
                
                // Prepare parameters for insertion with type safety (ADR-031)
                def params = [
                    stm_id: stepId,
                    phm_id: UUID.fromString(stepData.phm_id as String),
                    tms_id_owner: Integer.parseInt(stepData.tms_id_owner as String),
                    stt_code: stepData.stt_code as String,
                    stm_number: Integer.parseInt(stepData.stm_number as String),
                    stm_name: stepData.stm_name as String,
                    stm_description: stepData.stm_description,
                    stm_duration_minutes: stepData.stm_duration_minutes ? Integer.parseInt(stepData.stm_duration_minutes as String) : null,
                    enr_id_target: Integer.parseInt(stepData.enr_id_target as String),
                    enr_id: stepData.enr_id ? Integer.parseInt(stepData.enr_id as String) : null,
                    stm_id_predecessor: stepData.stm_id_predecessor ? UUID.fromString(stepData.stm_id_predecessor as String) : null,
                    created_by: 'admin',
                    created_at: new Timestamp(System.currentTimeMillis()),
                    updated_by: 'admin',
                    updated_at: new Timestamp(System.currentTimeMillis())
                ]
                
                def insertQuery = '''
                    INSERT INTO steps_master_stm (
                        stm_id, phm_id, tms_id_owner, stt_code, stm_number, 
                        stm_name, stm_description, stm_duration_minutes, 
                        enr_id_target, enr_id, stm_id_predecessor,
                        created_by, created_at, updated_by, updated_at
                    ) VALUES (
                        :stm_id, :phm_id, :tms_id_owner, :stt_code, :stm_number,
                        :stm_name, :stm_description, :stm_duration_minutes,
                        :enr_id_target, :enr_id, :stm_id_predecessor,
                        :created_by, :created_at, :updated_by, :updated_at
                    )
                '''
                
                sql.executeUpdate(insertQuery, params)
                
                // Retrieve the created step as DTO
                return findMasterByIdAsDTO(stepId)
                
            } catch (SQLException e) {
                log.error("Database error creating master step: ${e.message}")
                throw e
            } catch (Exception e) {
                log.error("Failed to create master step from DTO: ${e.message}")
                throw new RuntimeException("Failed to create master step", e)
            }
        }
    }

    /**
     * Update an existing step master from DTO
     * Added for US-056C Phase 2 API integration
     * 
     * @param stepMasterId UUID of step to update
     * @param stepData Map with updated data
     * @return Updated StepMasterDTO
     */
    StepMasterDTO updateMasterFromDTO(UUID stepMasterId, Map stepData) {
        log.debug("Updating master step ${stepMasterId} from DTO data")
        
        if (!stepMasterId) {
            throw new IllegalArgumentException("Step master ID cannot be null")
        }
        if (!stepData) {
            throw new IllegalArgumentException("Step data cannot be null")
        }
        
        return DatabaseUtil.withSql { sql ->
            try {
                // Build dynamic update query based on provided fields
                def updateFields = []
                Map<String, Object> params = [stm_id: stepMasterId]
                
                // Type-safe parameter extraction (ADR-031)
                if (stepData.stt_code != null) {
                    updateFields << "stt_code = :stt_code"
                    params.stt_code = stepData.stt_code as String
                }
                if (stepData.stm_number != null) {
                    updateFields << "stm_number = :stm_number"
                    params.stm_number = Integer.parseInt(stepData.stm_number as String)
                }
                if (stepData.stm_name != null) {
                    updateFields << "stm_name = :stm_name"
                    params.stm_name = stepData.stm_name as String
                }
                if (stepData.stm_description != null) {
                    updateFields << "stm_description = :stm_description"
                    params.stm_description = stepData.stm_description as String
                }
                if (stepData.stm_duration_minutes != null) {
                    updateFields << "stm_duration_minutes = :stm_duration_minutes"
                    params.stm_duration_minutes = Integer.parseInt(stepData.stm_duration_minutes as String)
                }
                if (stepData.tms_id_owner != null) {
                    updateFields << "tms_id_owner = :tms_id_owner"
                    params.tms_id_owner = Integer.parseInt(stepData.tms_id_owner as String)
                }
                if (stepData.enr_id_target != null) {
                    updateFields << "enr_id_target = :enr_id_target"
                    params.enr_id_target = Integer.parseInt(stepData.enr_id_target as String)
                }
                if (stepData.enr_id != null) {
                    updateFields << "enr_id = :enr_id"
                    params.enr_id = Integer.parseInt(stepData.enr_id as String)
                }
                if (stepData.stm_id_predecessor != null) {
                    updateFields << "stm_id_predecessor = :stm_id_predecessor"
                    params.stm_id_predecessor = stepData.stm_id_predecessor == 'null' ? null : UUID.fromString(stepData.stm_id_predecessor as String)
                }
                if (stepData.phm_id != null) {
                    updateFields << "phm_id = :phm_id"
                    params.phm_id = UUID.fromString(stepData.phm_id as String)
                }
                
                // Always update timestamp
                updateFields << "updated_at = :updated_at"
                params.updated_at = new Timestamp(System.currentTimeMillis())
                updateFields << "updated_by = :updated_by"
                params.updated_by = 'admin' as String
                
                if (updateFields.isEmpty()) {
                    throw new IllegalArgumentException("No fields to update")
                }
                
                def updateQuery = """
                    UPDATE steps_master_stm 
                    SET ${updateFields.join(', ')}
                    WHERE stm_id = :stm_id
                """
                
                def rowsUpdated = sql.executeUpdate(updateQuery, params)
                
                if (rowsUpdated == 0) {
                    throw new IllegalArgumentException("Step master not found: ${stepMasterId}")
                }
                
                // Retrieve the updated step as DTO
                return findMasterByIdAsDTO(stepMasterId)
                
            } catch (SQLException e) {
                log.error("Database error updating master step: ${e.message}")
                throw e
            } catch (Exception e) {
                log.error("Failed to update master step from DTO: ${e.message}")
                throw new RuntimeException("Failed to update master step", e)
            }
        }
    }

    /**
     * Delete (archive) a step master
     * Added for US-056C Phase 2 API integration
     * 
     * @param stepMasterId UUID of step to delete
     * @return true if deleted successfully
     */
    boolean deleteMaster(UUID stepMasterId) {
        log.debug("Deleting master step ${stepMasterId}")
        
        if (!stepMasterId) {
            throw new IllegalArgumentException("Step master ID cannot be null")
        }
        
        return DatabaseUtil.withSql { sql ->
            try {
                // Check if step has instances
                def instanceCount = sql.firstRow(
                    'SELECT COUNT(*) as count FROM steps_instance_sti WHERE stm_id = ?',
                    [stepMasterId]
                ).count as Integer
                
                if (instanceCount > 0) {
                    throw new IllegalStateException("Cannot delete step master with ${instanceCount} active instances")
                }
                
                // Delete related data first (cascade)
                sql.execute('DELETE FROM instructions_master_inm WHERE stm_id = ?', [stepMasterId])
                sql.execute('DELETE FROM steps_master_stm_x_teams_tms_impacted WHERE stm_id = ?', [stepMasterId])
                sql.execute('DELETE FROM labels_lbl_x_steps_master_stm WHERE stm_id = ?', [stepMasterId])
                sql.execute('DELETE FROM steps_master_stm_x_iteration_types_itt WHERE stm_id = ?', [stepMasterId])
                
                // Delete the master step
                def rowsDeleted = sql.executeUpdate(
                    'DELETE FROM steps_master_stm WHERE stm_id = ?',
                    [stepMasterId]
                )
                
                return rowsDeleted > 0
                
            } catch (SQLException e) {
                log.error("Database error deleting master step: ${e.message}")
                throw e
            } catch (Exception e) {
                log.error("Failed to delete master step: ${e.message}")
                throw new RuntimeException("Failed to delete master step", e)
            }
        }
    }
    
    // ========================================
    // Instance DTO Operations - US-056C Phase 2
    // ========================================
    
    /**
     * Create a new step instance from DTO
     * Added for US-056C Phase 2 API integration
     * 
     * @param instanceData Map with instance creation data
     * @return Created StepInstanceDTO
     */
    StepInstanceDTO createInstanceFromDTO(Map instanceData) {
        log.debug("Creating instance step from DTO data")
        
        if (!instanceData) {
            throw new IllegalArgumentException("Instance data cannot be null")
        }
        
        // Validate required fields
        def requiredFields = ['stm_id', 'phi_id', 'sti_name']
        for (field in requiredFields) {
            if (!instanceData[field]) {
                throw new IllegalArgumentException("Missing required field: ${field}")
            }
        }
        
        return (DatabaseUtil.withSql { sql ->
            try {
                def instanceId = UUID.randomUUID()
                
                // Type-safe parameter extraction (ADR-031)
                Map<String, Object> params = [
                    sti_id: instanceId,
                    stm_id: UUID.fromString(instanceData.stm_id as String),
                    phi_id: UUID.fromString(instanceData.phi_id as String),
                    sti_name: instanceData.sti_name as String,
                    sti_description: instanceData.sti_description as String ?: null,
                    sti_status: instanceData.sti_status ? Integer.parseInt(instanceData.sti_status as String) : 1, // Default: NOT_STARTED (ID lookup via StatusService)
                    sti_start_time: instanceData.sti_start_time ? Timestamp.valueOf(instanceData.sti_start_time as String) : null,
                    sti_end_time: instanceData.sti_end_time ? Timestamp.valueOf(instanceData.sti_end_time as String) : null,
                    sti_duration_minutes: instanceData.sti_duration_minutes ? Integer.parseInt(instanceData.sti_duration_minutes as String) : null,
                    created_by: 'admin',
                    updated_by: 'admin'
                ]
                
                def insertQuery = """
                    INSERT INTO steps_instance_sti (
                        sti_id, stm_id, phi_id, sti_name, sti_description,
                        sti_status, sti_start_time, sti_end_time,
                        sti_duration_minutes, created_by, updated_by
                    ) VALUES (
                        :sti_id, :stm_id, :phi_id, :sti_name, :sti_description,
                        :sti_status, :sti_start_time, :sti_end_time,
                        :sti_duration_minutes, :created_by, :updated_by
                    )
                """
                
                sql.executeUpdate(insertQuery, params)
                
                // Retrieve the created instance as DTO
                return findByInstanceIdAsDTO(instanceId)
                
            } catch (SQLException e) {
                log.error("Database error creating instance step: ${e.message}")
                if (e.getSQLState() == "23503") {
                    throw new IllegalArgumentException("Invalid foreign key reference", e)
                } else if (e.getSQLState() == "23505") {
                    throw new IllegalArgumentException("Duplicate instance detected", e)
                }
                throw e
            } catch (Exception e) {
                log.error("Failed to create instance step from DTO: ${e.message}")
                throw new RuntimeException("Failed to create instance step", e)
            }
        }) as StepInstanceDTO
    }
    
    /**
     * Update an existing step instance from DTO
     * Added for US-056C Phase 2 API integration
     * 
     * @param instanceId UUID of instance to update
     * @param instanceData Map with updated data
     * @return Updated StepInstanceDTO
     */
    StepInstanceDTO updateInstanceFromDTO(UUID instanceId, Map instanceData) {
        log.debug("Updating instance step ${instanceId} from DTO data")
        
        if (!instanceId) {
            throw new IllegalArgumentException("Instance ID cannot be null")
        }
        if (!instanceData) {
            throw new IllegalArgumentException("Instance data cannot be null")
        }
        
        return (DatabaseUtil.withSql { sql ->
            try {
                // Build dynamic update query based on provided fields
                def updateFields = []
                Map<String, Object> params = [sti_id: instanceId]
                
                // Type-safe parameter extraction (ADR-031)
                if (instanceData.sti_name != null) {
                    updateFields << "sti_name = :sti_name"
                    params.sti_name = instanceData.sti_name as String
                }
                if (instanceData.sti_description != null) {
                    updateFields << "sti_description = :sti_description"
                    params.sti_description = instanceData.sti_description as String
                }
                if (instanceData.sti_status != null) {
                    updateFields << "sti_status = :sti_status"
                    params.sti_status = Integer.parseInt(instanceData.sti_status as String)
                }
                // Note: Many legacy fields do not exist in current schema
                // Using only valid fields from steps_instance_sti table
                if (instanceData.sti_start_time != null) {
                    updateFields << "sti_start_time = :sti_start_time"
                    params.sti_start_time = instanceData.sti_start_time == 'null' ? null : Timestamp.valueOf(instanceData.sti_start_time as String)
                }
                if (instanceData.sti_end_time != null) {
                    updateFields << "sti_end_time = :sti_end_time"
                    params.sti_end_time = instanceData.sti_end_time == 'null' ? null : Timestamp.valueOf(instanceData.sti_end_time as String)
                }
                if (instanceData.sti_duration_minutes != null) {
                    updateFields << "sti_duration_minutes = :sti_duration_minutes"
                    params.sti_duration_minutes = instanceData.sti_duration_minutes == 'null' ? null : Integer.parseInt(instanceData.sti_duration_minutes as String)
                }

                // Always update timestamp with valid schema fields
                updateFields << "updated_at = CURRENT_TIMESTAMP"
                updateFields << "updated_by = :updated_by"
                params.updated_by = 'admin' as String
                
                if (updateFields.isEmpty()) {
                    throw new IllegalArgumentException("No fields to update")
                }
                
                def updateQuery = """
                    UPDATE steps_instance_sti 
                    SET ${updateFields.join(', ')}
                    WHERE sti_id = :sti_id
                """
                
                def rowsUpdated = sql.executeUpdate(updateQuery, params)
                
                if (rowsUpdated == 0) {
                    throw new IllegalArgumentException("Step instance not found: ${instanceId}")
                }
                
                // Retrieve the updated instance as DTO
                return findByInstanceIdAsDTO(instanceId)
                
            } catch (SQLException e) {
                log.error("Database error updating instance step: ${e.message}")
                throw e
            } catch (Exception e) {
                log.error("Failed to update instance step from DTO: ${e.message}")
                throw new RuntimeException("Failed to update instance step", e)
            }
        }) as StepInstanceDTO
    }

    /**
     * Get complete step instance data for email rendering (TD-015 Critical Bug Fix)
     *
     * This method retrieves ALL 35+ fields required by email templates to prevent
     * raw GSP syntax from appearing in production emails.
     *
     * CRITICAL: This method is the authoritative source for email data binding.
     * It includes:
     * - Core step fields (code, name, description, duration, status)
     * - Contextual information (environment, team, predecessors, successors)
     * - Rich data arrays (instructions with completion status, recent comments)
     * - Migration/iteration context
     * - Team relationships (assigned team + impacted teams)
     *
     * @param stepInstanceId UUID of the step instance
     * @return Map with all fields needed by email templates
     * @throws NotFoundException if step instance doesn't exist
     */
    Map getCompleteStepForEmail(UUID stepInstanceId) {
        return DatabaseUtil.withSql { sql ->
            // Step 1: Get complete step data with all joined relationships
            def stepData = sql.firstRow('''
                SELECT
                    -- Core Step Instance Fields
                    sti.sti_id,
                    sti.sti_name,
                    sti.sti_description,
                    sti.sti_duration_minutes,
                    sti.sti_status,

                    -- Step Master Fields
                    stm.stm_id,
                    stm.stt_code,
                    stm.stm_number,
                    stm.stm_name as stm_name,
                    stm.stm_description as stm_description,

                    -- Environment Context
                    env.env_name as environment_name,
                    enr.enr_name as environment_role_name,

                    -- Team Context (Assigned Team)
                    team.tms_id as team_id,
                    team.tms_name as team_name,
                    team.tms_email as team_email,

                    -- Predecessor Information
                    pred.stt_code as predecessor_stt_code,
                    pred.stm_number as predecessor_stm_number,
                    pred.stm_name as predecessor_name,

                    -- Successor Information (find steps that have THIS step as predecessor)
                    succ.stt_code as successor_stt_code,
                    succ.stm_number as successor_stm_number,
                    succ.stm_name as successor_name,

                    -- Migration/Iteration Context
                    mig.mig_code,
                    mig.mig_name as migration_name,
                    mig.mig_description as migration_description,
                    ite.ite_code,
                    ite.ite_name as iteration_name,
                    ite.ite_description as iteration_description,

                    -- Plan/Sequence/Phase Context (for complete hierarchy)
                    plm.plm_name as plan_name,
                    sqm.sqm_name as sequence_name,
                    phm.phm_name as phase_name

                FROM steps_instance_sti sti

                -- Join to master step
                JOIN steps_master_stm stm ON sti.stm_id = stm.stm_id

                -- Join to environment
                LEFT JOIN environment_roles_enr enr ON sti.enr_id = enr.enr_id
                LEFT JOIN environments_env_x_iterations_ite eei ON eei.ite_id = sti.ite_id AND eei.enr_id = sti.enr_id
                LEFT JOIN environments_env env ON eei.env_id = env.env_id

                -- Join to assigned team
                LEFT JOIN teams_tms team ON stm.tms_id_owner = team.tms_id

                -- Join to predecessor step
                LEFT JOIN steps_master_stm pred ON stm.stm_id_predecessor = pred.stm_id

                -- Join to successor step (steps that reference THIS step as predecessor)
                LEFT JOIN steps_master_stm succ ON succ.stm_id_predecessor = stm.stm_id

                -- Join to hierarchy
                JOIN phases_instance_phi phi ON sti.phi_id = phi.phi_id
                JOIN phases_master_phm phm ON phi.phm_id = phm.phm_id
                JOIN sequences_instance_sqi sqi ON phi.sqi_id = sqi.sqi_id
                JOIN sequences_master_sqm sqm ON sqi.sqm_id = sqm.sqm_id
                JOIN plans_instance_pli pli ON sqi.pli_id = pli.pli_id
                JOIN plans_master_plm plm ON pli.plm_id = plm.plm_id
                JOIN iterations_ite ite ON pli.ite_id = ite.ite_id
                JOIN migrations_mig mig ON ite.mig_id = mig.mig_id

                WHERE sti.sti_id = :stepInstanceId
            ''', [stepInstanceId: stepInstanceId])

            if (!stepData) {
                throw new RuntimeException("Step instance not found: ${stepInstanceId}")
            }

            // Step 2: Get instructions with completion status
            def instructions = sql.rows('''
                SELECT
                    ini.ini_id,
                    inm.inm_body as ini_name,
                    inm.inm_body as ini_description,
                    CASE
                        WHEN ini.ini_is_completed THEN 'COMPLETED'
                        ELSE 'PENDING'
                    END as ini_status,
                    inm.inm_order as ini_order,
                    ini.ini_completed_at,
                    ini.usr_id_completed_by,
                    inm.tms_id as instruction_team_id,
                    tms.tms_name as instruction_team_name
                FROM instructions_instance_ini ini
                JOIN instructions_master_inm inm ON ini.inm_id = inm.inm_id
                LEFT JOIN teams_tms tms ON inm.tms_id = tms.tms_id
                WHERE ini.sti_id = :stepInstanceId
                ORDER BY inm.inm_order
            ''', [stepInstanceId: stepInstanceId])

            // Step 3: Get recent comments (last 3)
            def recentComments = sql.rows('''
                SELECT
                    u.usr_full_name as author_name,
                    u.usr_code as author_username,
                    c.created_at,
                    c.cmt_text as comment_text
                FROM comments_cmt c
                JOIN users_usr u ON c.usr_id = u.usr_id
                WHERE c.sti_id = :stepInstanceId
                ORDER BY c.created_at DESC
                LIMIT 3
            ''', [stepInstanceId: stepInstanceId])

            // Step 4: Get impacted teams
            def impactedTeams = sql.rows('''
                SELECT
                    tms.tms_id,
                    tms.tms_name,
                    tms.tms_email
                FROM steps_master_stm_x_teams_tms_impacted smti
                JOIN teams_tms tms ON smti.tms_id = tms.tms_id
                WHERE smti.stm_id = :stmId
            ''', [stmId: stepData.stm_id])

            // Step 5: Format step code (e.g., "AUT-003")
            def stepCode = "${stepData.stt_code}-${String.format('%03d', stepData.stm_number as Integer)}"

            // Step 6: Format predecessor code if exists
            def predecessorCode = null
            if (stepData.predecessor_stt_code && stepData.predecessor_stm_number) {
                predecessorCode = "${stepData.predecessor_stt_code}-${String.format('%03d', stepData.predecessor_stm_number as Integer)}"
            }

            // Step 7: Format successor code if exists
            def successorCode = null
            if (stepData.successor_stt_code && stepData.successor_stm_number) {
                successorCode = "${stepData.successor_stt_code}-${String.format('%03d', stepData.successor_stm_number as Integer)}"
            }

            // Step 8: Build complete map with ALL 35+ fields required by templates
            return [
                // Core Step Instance Fields (6 fields)
                sti_id: stepData.sti_id,
                sti_code: stepCode,
                sti_name: stepData.sti_name ?: stepData.stm_name,
                sti_description: stepData.sti_description ?: stepData.stm_description,
                sti_duration_minutes: stepData.sti_duration_minutes ?: 0,
                sti_status: stepData.sti_status,

                // Contextual Information (6 fields)
                environment_name: stepData.environment_name ?: 'Not assigned',
                environment_role_name: stepData.environment_role_name,
                team_id: stepData.team_id,
                team_name: stepData.team_name ?: 'Unassigned',
                team_email: stepData.team_email,

                // Predecessor/Successor Information (6 fields)
                predecessor_code: predecessorCode,
                predecessor_name: stepData.predecessor_name,
                successor_code: successorCode,
                successor_name: stepData.successor_name,
                has_predecessor: predecessorCode != null,
                has_successor: successorCode != null,

                // Migration/Iteration Context (6 fields)
                migration_code: stepData.mig_code,
                migration_name: stepData.migration_name,
                migration_description: stepData.migration_description,
                iteration_code: stepData.ite_code,
                iteration_name: stepData.iteration_name,
                iteration_description: stepData.iteration_description,

                // Hierarchical Context (3 fields)
                plan_name: stepData.plan_name,
                sequence_name: stepData.sequence_name,
                phase_name: stepData.phase_name,

                // Rich Data Arrays (4 arrays)
                instructions: instructions,
                completedInstructions: instructions.findAll { it.ini_status == 'COMPLETED' },
                pendingInstructions: instructions.findAll { it.ini_status == 'PENDING' },
                recentComments: recentComments,

                // Team Relationships (1 array)
                impacted_teams: impactedTeams,

                // Computed Metadata (4 fields)
                total_instructions: instructions.size(),
                completed_instruction_count: instructions.count { it.ini_status == 'COMPLETED' },
                pending_instruction_count: instructions.count { it.ini_status == 'PENDING' },
                instruction_completion_percentage: instructions.isEmpty() ? 0 :
                    (instructions.count { it.ini_status == 'COMPLETED' } / instructions.size() * 100).round(0)
            ]
        }
    }

}
